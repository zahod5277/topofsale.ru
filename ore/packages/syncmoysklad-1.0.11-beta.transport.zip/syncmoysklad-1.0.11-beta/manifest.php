<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for syncMoySklad

1.0.11-beta (11.04.2017)
==============
- Fix "updateData"
- Add "compatibility_1c" setting

1.0.9-beta - 1.0.10-beta (14.03.2017)
==============
- Fix "customentity" type

1.0.8-beta (14.03.2017)
==============
- Fix "boolean" type

1.0.7-beta (14.03.2017)
==============
- Add "customentity"

1.0.6-beta (04.03.2017)
==============
- Add "filter_stock_store" setting
- Add "sync_read_store" step
- Change "httpBuildQuery" [SyncMoySkladTools]
- Change "stepSyncReadStock" [modSyncMoySkladSyncProcessor]

1.0.5-beta (28.02.2017)
==============
- Add "service"

1.0.4-beta (21.02.2017)
==============
- Fix calculate price for multiple currencies

1.0.3-beta (21.02.2017)
==============
- Fix compatibility with PHP < 5.6

1.0.2-beta (19.02.2017)
==============
- Fix "baseSync" resolver

1.0.1-beta (13.02.2017)
==============
- Add "baseSync" resolver

1.0.0-beta
==============
- Initial',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
syncMoySklad
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd29a3e459492347d1a8f530403410f22',
      'native_key' => 'syncmoysklad',
      'filename' => 'modNamespace/1f40adb6d94af2afc81b1f9969ef7251.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6ca8383d970c069e4693d5f6f1e13c7',
      'native_key' => 'sync_moysklad_actions',
      'filename' => 'modSystemSetting/d3c93f717ae5552950941c14078e3d5d.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2b49c8846f31d42548116aa6ac041d8',
      'native_key' => 'sync_moysklad_api_endpoint',
      'filename' => 'modSystemSetting/38c529a32b1b45db3f4014af0c45f94c.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ba507b475cb1e7f23e369108fb0ac71',
      'native_key' => 'sync_moysklad_api_user',
      'filename' => 'modSystemSetting/d38a0a77a9e02566328a1898e7a16573.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8a511bc782902d90d6b4c1c1e9694b6',
      'native_key' => 'sync_moysklad_api_password',
      'filename' => 'modSystemSetting/f9439c4d63b131b78e6588c9d7448d61.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29aa10904f5309a33f52cd7cd60dd3a3',
      'native_key' => 'sync_moysklad_api_limit',
      'filename' => 'modSystemSetting/a8dfeaebeebfc24613a24bb5dac26ad6.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ffb6217e58790514bbae2cbd247981d',
      'native_key' => 'sync_moysklad_sync_lock',
      'filename' => 'modSystemSetting/a46cc6ee915a95502b6ad11ba70ad338.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2814968a705549caa7d4d248784fce42',
      'native_key' => 'sync_moysklad_sync_archived',
      'filename' => 'modSystemSetting/70896ac2825b504c1df5fafd4612145f.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca2e6ba612540436f7fac5859546b270',
      'native_key' => 'sync_moysklad_sync_folder',
      'filename' => 'modSystemSetting/295e4bd9ec4e07f8c13fc9e55847415a.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ed9776df65183ef751c250627c91bd9',
      'native_key' => 'sync_moysklad_sync_parent',
      'filename' => 'modSystemSetting/2aa33caff99e4b21f1e2b6c0e697d0d4.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '114a0ec4a2378ffa3cd02be8f5ae6a21',
      'native_key' => 'sync_moysklad_currency',
      'filename' => 'modSystemSetting/2dffc979b196df74b98a07b5df6e0939.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '426c3106583feeb500b111d282862916',
      'native_key' => 'sync_moysklad_currency_rate',
      'filename' => 'modSystemSetting/408d245c2f1f76c6783ea6e299ef7e94.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '795acb7d8ae09f7e6de60a2456be2010',
      'native_key' => 'sync_moysklad_web_hook_url',
      'filename' => 'modSystemSetting/1d29775fb06b1418ff82d66169fb5757.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d82563f67ce6e1d98a377b4d9ec236f',
      'native_key' => 'sync_moysklad_process_tmp',
      'filename' => 'modSystemSetting/837ae5f86bbaa46c55e95abcab9884f7.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '406aea1ee9753a76eeb54c88aacc07da',
      'native_key' => 'sync_moysklad_process_image',
      'filename' => 'modSystemSetting/ed20cce9d4f7a01b1b1d7c5bba95e2ca.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2644ac47f3b47ac339b3008f5ed4f233',
      'native_key' => 'sync_moysklad_process_price',
      'filename' => 'modSystemSetting/0526f76972e15818c7dd7d4b46eead2f.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b642aa6efc7c7c0fc0bd811106d5ff95',
      'native_key' => 'sync_moysklad_process_modification',
      'filename' => 'modSystemSetting/3cde38ab11b8430a17f9b1a767b3f9de.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4c8178d865174728884272ca95324f8',
      'native_key' => 'sync_moysklad_process_stock',
      'filename' => 'modSystemSetting/6ec05db0d39de9ce72dd4267ef9ee5bf.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '897473f1b4a36652a002ffaf6e859053',
      'native_key' => 'sync_moysklad_process_service',
      'filename' => 'modSystemSetting/05853b6c5007562b744e2d1bcdfff219.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c916d45357cf685121e5ce3666127dba',
      'native_key' => 'sync_moysklad_compatibility_1c',
      'filename' => 'modSystemSetting/7e367d277bc3e38bb6abf2ad7f1e88e4.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85168eee6cb55720d6dcd5df369d61d3',
      'native_key' => 'sync_moysklad_product_class_key',
      'filename' => 'modSystemSetting/c80a19164d2393cb35b12c65fd73a131.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20c76f03dae2b409aeeecdadbb5c19df',
      'native_key' => 'sync_moysklad_product_template',
      'filename' => 'modSystemSetting/b89b45c6a91a117672d4574c8d818651.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f877d1fd379e51ed673818fbb6514206',
      'native_key' => 'sync_moysklad_product_published',
      'filename' => 'modSystemSetting/e96558dfc15ce83b0e37ac42cecdcc81.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7206775b7ba1bdee93e98f6f26ca8986',
      'native_key' => 'sync_moysklad_product_skip_fields_on_upd',
      'filename' => 'modSystemSetting/4f7e079bcb3c46bb0b78863b4019c230.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0f5d49c3853377a86f366eb81ecefc',
      'native_key' => 'sync_moysklad_product_fields',
      'filename' => 'modSystemSetting/a95c93c6434b7dc5fb68fda9d3157abf.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da52d9a8b6519146d7eafaf99521ede3',
      'native_key' => 'sync_moysklad_product_attributes',
      'filename' => 'modSystemSetting/9d7ede39b2f19b55a8161a4b8e5f1328.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5d693ed657871830c6d3dbeff18c333',
      'native_key' => 'sync_moysklad_product_stock',
      'filename' => 'modSystemSetting/af4588788ae9e8769a7dc5b532c49f24.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a18f4d669858e43167132243ebd33f70',
      'native_key' => 'sync_moysklad_product_price',
      'filename' => 'modSystemSetting/d55562143dbc905c2b73b5d4f674358d.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8ef87631642e86f704c1954c63cf5ff',
      'native_key' => 'sync_moysklad_product_process_on_import_upd',
      'filename' => 'modSystemSetting/11d06503544197a3a53efb05ea67edfd.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b6bcd3335e701185af9d24221e54daa',
      'native_key' => 'sync_moysklad_product_process_on_import_cre',
      'filename' => 'modSystemSetting/9567e45e9da8dd7d34d3302850c2c75f.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e81616e663b604ede71e043bb93fbcb',
      'native_key' => 'sync_moysklad_product_process_on_export_upd',
      'filename' => 'modSystemSetting/a9bb8d0e48cd0a0670b9d4152c758131.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca7483c3ecfd9844dd632a2ce5e8f29d',
      'native_key' => 'sync_moysklad_product_process_on_export_cre',
      'filename' => 'modSystemSetting/ae5ae09e9d7de080eaabacea6278acce.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '717bb408085f233e13620b1cab445000',
      'native_key' => 'sync_moysklad_product_process_attributes_on_import',
      'filename' => 'modSystemSetting/b7d85d42639a3ffc11a3523b176c1589.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c30ef736771a69739696081599d71c59',
      'native_key' => 'sync_moysklad_product_process_attributes_on_export',
      'filename' => 'modSystemSetting/670e7d8c5f1da64a7b83bfbc40a16616.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '258ced15d4826b40af01ddb08f089569',
      'native_key' => 'sync_moysklad_product_process_image_on_import_cre',
      'filename' => 'modSystemSetting/14e67d2586d209df5f60c482cbf742d5.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9631c84523822e5867fe495918233ae9',
      'native_key' => 'sync_moysklad_product_process_image_on_import_upd',
      'filename' => 'modSystemSetting/afd09341bcb0469d30a652e5ebab8b07.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43860b0b335c6a6e617865e0bba01a22',
      'native_key' => 'sync_moysklad_product_process_image_on_export_cre',
      'filename' => 'modSystemSetting/e5fdb49a614e413a714c382c65bde9e0.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43ed0a24ba51c530aaf27baca9e91777',
      'native_key' => 'sync_moysklad_product_process_image_on_export_upd',
      'filename' => 'modSystemSetting/4849d12d9a092b07a9d15b5bb786fec7.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2ea0eb41db94b49188df392e08bf1f4',
      'native_key' => 'sync_moysklad_product_process_price_on_import_cre',
      'filename' => 'modSystemSetting/5420ea4c802f78c5a425e25c62ef83af.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0c9e8835a35797df6e9e894ff2d4437',
      'native_key' => 'sync_moysklad_product_process_price_on_import_upd',
      'filename' => 'modSystemSetting/88e555fe341bc7047a3ccd857761cb10.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7cbc102a3476d40f0ef83bdc92d32f5',
      'native_key' => 'sync_moysklad_product_process_price_on_export_cre',
      'filename' => 'modSystemSetting/6ca1ea2f812e037757bca93b74c92e60.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e662ee50ee9a37a176bafa87ce98349',
      'native_key' => 'sync_moysklad_product_process_price_on_export_upd',
      'filename' => 'modSystemSetting/cbf5d6e9ddc1a97b6841fe111103e40d.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd13d103e0c539bb2b6ad6ff8ac832d2a',
      'native_key' => 'sync_moysklad_product_process_stock',
      'filename' => 'modSystemSetting/eb6f7fef1ed7ec1f88feda484bd3cd43.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e79ae1afd6a22c37dce2fac73e7f314',
      'native_key' => 'sync_moysklad_category_class_key',
      'filename' => 'modSystemSetting/fae93d2422c264a4a46ba8003b6b194f.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e004964e36a384f5c73243a5b5c52a3',
      'native_key' => 'sync_moysklad_category_template',
      'filename' => 'modSystemSetting/7c3898999a82f2dc47598b26e187d287.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6231d5b72cfd815bf99d8ac7183b8b82',
      'native_key' => 'sync_moysklad_category_published',
      'filename' => 'modSystemSetting/762ab87fe3a7264fc3cc572cf0ce25db.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '864566672248959104f2201e3b029d4a',
      'native_key' => 'sync_moysklad_category_skip_fields_on_upd',
      'filename' => 'modSystemSetting/c166e0da3c9e5b1d16435d206052f17c.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5888d354c3f8c07bdf218e3b2497360',
      'native_key' => 'sync_moysklad_category_fields',
      'filename' => 'modSystemSetting/800f937df3de358b6286e72d044bddb2.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7014eaeb4a97b229ae2010986b0c4327',
      'native_key' => 'sync_moysklad_category_process_on_import_upd',
      'filename' => 'modSystemSetting/41a4e9401e5b21af13f4209a50879cdf.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ede2d463b3e01063ad38e3c3997bbda7',
      'native_key' => 'sync_moysklad_category_process_on_import_cre',
      'filename' => 'modSystemSetting/417f645e69f7aa1c1bf024a747935c57.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c90d7e57bf27f9191ee6aa30b19bffc3',
      'native_key' => 'sync_moysklad_category_process_on_export_upd',
      'filename' => 'modSystemSetting/20452bb23b9033df0decfdb247dd17ae.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45bb688304c9af0b49b5028f4c0de94e',
      'native_key' => 'sync_moysklad_category_process_on_export_cre',
      'filename' => 'modSystemSetting/1480150fa8c0b033087b846e48754153.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9f27fc88bf17b545665deb52fbe65c2',
      'native_key' => 'sync_moysklad_modification_fields',
      'filename' => 'modSystemSetting/3be6db224c8f8c749b08ec5b0855998a.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '706d0d3b2afd3e0aa6b1df1bcc129cd1',
      'native_key' => 'sync_moysklad_modification_characteristics',
      'filename' => 'modSystemSetting/7859167fcc1d3a6a90a2c4ff27d9cf56.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ed9243ec88f74b79171977619af3174',
      'native_key' => 'sync_moysklad_modification_stock',
      'filename' => 'modSystemSetting/b3a2d86cb0a096857fff9995fd980b29.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0f3b40e5f5d39ae29544da065bd235f',
      'native_key' => 'sync_moysklad_modification_price',
      'filename' => 'modSystemSetting/757371ac7b4595a7abf4fbb7b288bbc3.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cc94e6ba49f3cd7865b2004bf8f130e',
      'native_key' => 'sync_moysklad_modification_process_on_import',
      'filename' => 'modSystemSetting/f7d43f34cc2de5872fc36caed826fa7b.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a772bb5a3a8a299b9dd0a7e11b32bcab',
      'native_key' => 'sync_moysklad_modification_process_on_export_upd',
      'filename' => 'modSystemSetting/e442306f9838ec9cfd2f60cfb88dd28f.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b06df24d8186c7db7c1c8c78ee48e96b',
      'native_key' => 'sync_moysklad_modification_process_on_export_cre',
      'filename' => 'modSystemSetting/6398e6b87e4088de8003dd9b8e7d5c5c.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '109b086ab34db107b6528f06c4c6169c',
      'native_key' => 'sync_moysklad_modification_process_char_on_export',
      'filename' => 'modSystemSetting/3f2cc64ff02cb39ad172c8d42d28a1f1.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095d7be9011b5d4e8c9969349547e3a9',
      'native_key' => 'sync_moysklad_modification_process_price_on_export',
      'filename' => 'modSystemSetting/a0a8e880fb5eba0f5e21931b140fb5d2.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0cd597ad57b9499827ad1ccbd7597d4',
      'native_key' => 'sync_moysklad_modification_process_stock',
      'filename' => 'modSystemSetting/fdeb870f41c3e3f87f7169a97022edde.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66c8fbbb7b33b138b1996f9a0e106c26',
      'native_key' => 'sync_moysklad_filter_stock_mode',
      'filename' => 'modSystemSetting/3cf7a7c9cbe9f7686f9e1d44e4af03da.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5973d705a3957d3861e48dabd07968',
      'native_key' => 'sync_moysklad_service_class_key',
      'filename' => 'modSystemSetting/48fe7673d7be057670fcdd5f89a5e21b.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec821ecc9009916874a673845fae0c10',
      'native_key' => 'sync_moysklad_service_template',
      'filename' => 'modSystemSetting/027da468caf40a74b20853a30431b678.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6ba2b5ada5207718f749225802a1d72',
      'native_key' => 'sync_moysklad_service_published',
      'filename' => 'modSystemSetting/e5c82d37c4e7cd951cac9a11f9f32dfb.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a62738ddc4490bd62702c5834615516f',
      'native_key' => 'sync_moysklad_service_skip_fields_on_upd',
      'filename' => 'modSystemSetting/4a09e6bde2150bfcce16f8047f5a4465.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faf798c481099c5dc4b92def085b4bb5',
      'native_key' => 'sync_moysklad_service_fields',
      'filename' => 'modSystemSetting/7aba128227d55d48a5f513fb86fce0e4.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53bda686f8dd191807da5619c8dadef0',
      'native_key' => 'sync_moysklad_service_price',
      'filename' => 'modSystemSetting/88e9df2b55afc0ddead01999b45d9fd2.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5415d37c30dd510c6590551cef80bdc9',
      'native_key' => 'sync_moysklad_service_process_on_import_upd',
      'filename' => 'modSystemSetting/dfc18c3f056f517142295d0af0e3ee12.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '201cc7ed32d4a39a1f9b33bf5238e126',
      'native_key' => 'sync_moysklad_service_process_on_import_cre',
      'filename' => 'modSystemSetting/d871c87f12dfac5e2664d47b1ec735d2.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca6707db80b9ce16e7409c63b2dd9328',
      'native_key' => 'sync_moysklad_service_process_on_export_upd',
      'filename' => 'modSystemSetting/986781a4cb60873b9a7067c2a261ebea.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5edbcd7d81945e830428d71779f6b09f',
      'native_key' => 'sync_moysklad_service_process_on_export_cre',
      'filename' => 'modSystemSetting/addde96423cd6ab0539ac03bb62a849e.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f6698e8f55004d5203bb0200bd55eb7',
      'native_key' => 'sync_moysklad_service_process_price_on_import_cre',
      'filename' => 'modSystemSetting/80b6274bdbdf5a510838031eaa6a2810.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '236a412daa30f50389ee29c1aa72659c',
      'native_key' => 'sync_moysklad_service_process_price_on_import_upd',
      'filename' => 'modSystemSetting/0b51d8d35417aead00a624ecaead4901.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50df38f42e4da5ae2678aad2f32fc993',
      'native_key' => 'sync_moysklad_service_process_price_on_export_cre',
      'filename' => 'modSystemSetting/60946133eb4fe2aebeb9484512c80d9e.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dcf5eb0f9bb97ab32a5f1dd5d879d15',
      'native_key' => 'sync_moysklad_service_process_price_on_export_upd',
      'filename' => 'modSystemSetting/73ad397b642ba0ee6babf21250f25b1c.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '582b99b9c427191088f8c3a812272dcf',
      'native_key' => 'sync_moysklad_service_process_attributes_on_import',
      'filename' => 'modSystemSetting/e96c24c3b277d853265d0a5ee57899a8.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e09295a693f3a743c8cd974b6f57b7c5',
      'native_key' => 'sync_moysklad_service_process_attributes_on_export',
      'filename' => 'modSystemSetting/c2791e481506d1ded19c2941c9cd676a.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18f49235df369456da8945e579f19aab',
      'native_key' => 'sync_moysklad_service_attributes',
      'filename' => 'modSystemSetting/0d6ddc359008fed7d55cd94a39b9413e.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef21cf2d229ab7aa31ea809fcf4c5833',
      'native_key' => 'sync_moysklad_filter_stock_store',
      'filename' => 'modSystemSetting/f985f559f938cd0a060dbf8de450e531.vehicle',
      'namespace' => 'syncmoysklad',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ab5baba3ff9f1548e660e57050203998',
      'native_key' => NULL,
      'filename' => 'modCategory/1f42e7a5ba5674364e8b9a169e4916a5.vehicle',
      'namespace' => 'syncmoysklad',
    ),
  ),
);