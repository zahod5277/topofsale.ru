<?php

/***** BASE ******/

/** @noinspection PhpIncludeInspection */
require_once dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/sync/processors/mgr/sync/sync.class.php';

class modSyncMoySkladMsCategoryBaseProcessor extends modSyncSyncProcessor
{

    /** @var Sync $Sync */
    public $Sync;
    /** @var SyncMoySkladTools $SyncTools */
    public $SyncTools;

    /** @var mixed|null $syncService */
    protected $syncService = 'moysklad';

    /**
     * @var array
     */
    protected $steps = array(
        "sync_init",
        "sync_close",
    );


    public function setSyncService($service = 'moysklad')
    {
        $this->syncService = $service;

        return $this->Sync->loadSyncTools($this->syncService);
    }

    public function createSyncObject($type = '', $action = '', $id, array $data = array(), $class = 'syncObject')
    {
        $object = parent::createSyncObject($type, $action, $id, $data, $class);

        return $object;
    }

    public function processSyncObject($object, $syncType, $syncAction, $class = 'syncEventObject')
    {
        $object = parent::processSyncObject($object, $syncType, $syncAction, $class);

        return $object;
    }


    public function getSyncResourceParentSyncData($rid = 0, $includeCurr = true)
    {
        $data = array();
        $parents = $this->getSyncResourceParents($rid, $includeCurr);

        foreach ($parents as $parent) {
            /** @var modResource $syncResource */
            if ($syncResource = $this->modx->getObject('modResource', (int)$parent)) {
                $syncService = $syncResource->get('sync_service');
                if ($syncService == $this->syncService) {
                    if ($data = $syncResource->get('sync_data')) {
                        return $data;
                    }
                }
            }
        }

        return $data;
    }

    public function getSyncResourceParents($rid = 0, $includeCurr = true)
    {

        $parents = parent::getSyncResourceParents($rid, $includeCurr);

        return $parents;
    }

    public function getSyncResourceChilds($rid = 0, $includeCurr = true)
    {
        $childs = parent::getSyncResourceChilds($rid, $includeCurr);

        return $childs;
    }

    public function getSyncExcludeTemplates()
    {
        $templates = $this->explodeAndClean($this->modx->getOption('sync_not_working_templates', null));

        return $templates;
    }

    public function getSyncResourceParentSyncPath($rid = 0, $includeCurr = true)
    {
        $data = $this->getSyncResourceParentSyncData($rid, $includeCurr);
        $syncPath = $this->modx->getOption('sync_path', $data);

        return $syncPath;
    }

    public function getSyncResourceParentSyncMeta($rid = 0, $includeCurr = true)
    {
        $data = $this->getSyncResourceParentSyncData($rid, $includeCurr);
        $syncMeta = $this->modx->getOption('meta', $data);

        /* поиск среди категорий моего склада */
        if (empty($syncMeta)) {
            $syncAction = "import";
            $classSync = "syncObject";
            $syncFolder = $this->getOption('sync_folder', null);

            $q = $this->modx->newQuery($classSync);
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncFolder,
            ));

            if ($syncObject = $this->modx->getObject($classSync, $q)) {
                $syncData = $syncObject->get('sync_data');
                $syncMeta = $this->modx->getOption('meta', $syncData);
            };
        }

        return $syncMeta;
    }

    public function getSyncResourceImportFolder($name = '', $syncParent = '')
    {
        $importFolder = $this->explodeAndClean($this->getOption('sync_folder', null));
        if (!empty($importFolder)) {
            $pathName = $this->explodeAndClean($syncParent, '/');
            $basePathName = reset($pathName);
            if (
                !in_array($name, $importFolder)
                AND
                !in_array($basePathName, $importFolder)
            ) {
                return false;
            }
        }

        return true;
    }

    public function getSyncObjectUuid(array $data = array())
    {
        return $this->SyncTools->getUuidByMeta($this->modx->getOption('meta', $data));
    }

    public function getSyncResourcePriceRate($syncId = null)
    {
        $rate = 0;

        $currency = $this->getOption('currency', null, 643);
        $syncType = "currency";
        $syncAction = "import";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_action"  => $syncAction,
            "{$classSync}.sync_service" => $this->syncService,
        ));

        if (empty($syncId)) {
            $q->where(array(
                "{$classSync}.sync_id" => $currency,
            ));
        } else {
            $q->where(array(
                "{$classSync}.sync_parent" => $syncId,
            ));
        }
        $q->limit(1);

        if ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncData = $syncObject->get('sync_data');
            $rate = $this->modx->getOption('rate', $syncData, 1, true);
        }
        if (empty($rate)) {
            $rate = 1;
        }

        $rate = $this->getOption('currency_rate', null, 1, true) / $rate;

        return $rate;
    }

    public function getSyncResourceCurrencySyncMeta($syncId = null)
    {
        $syncMeta = array();

        $currency = $this->getOption('currency', null, 643);
        $syncType = "currency";
        $syncAction = "import";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_id"      => $currency,
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_action"  => $syncAction,
            "{$classSync}.sync_service" => $this->syncService,
        ));
        $q->limit(1);

        if ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncData = $syncObject->get('sync_data');
            $syncMeta = $this->modx->getOption('meta', $syncData);
        }

        return $syncMeta;
    }

    /* задаемм корневую категорию синхронизации */
    public function setSyncFolder()
    {
        /* задаемм корневую категорию */
        $syncFolder = trim($this->getOption('sync_folder', null));
        $syncParent = (int)$this->getOption('sync_parent', null);

        /* не пустая категория и не пустой каталог выгрузки */
        if (!empty($syncFolder) AND !empty($syncParent)) {
            $syncAction = "import";
            $classSync = "syncObject";
            $classResource = "modResource";

            $q = $this->modx->newQuery($classSync);
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncFolder,
            ));

            $syncObject = $this->modx->getObject($classSync, $q);
            $syncResource = $this->modx->getObject($classResource, $syncParent);

            if ($syncObject AND $syncResource) {
                $syncResource->set('sync_id', $syncObject->get('sync_id'));
                $syncResource->set('sync_service', $this->syncService);
                $syncResource->save();

                return true;
            } else {
                $this->log("[" . __CLASS__ . "] Error set sync parent", '', true);
            }
        }

        return false;
    }

    /* обрабытываем пагинацию запроса */
    public function processSyncFilters($data = array())
    {
        $filters = array();

        if (!empty($data)) {
            $meta = (array)$this->modx->getOption('meta', $data);
            if ($nextHref = $this->modx->getOption('nextHref', $meta)) {
                $tmp = parse_url($nextHref);
                if (isset($tmp['query'])) {
                    parse_str($tmp['query'], $filters);
                    ksort($filters);
                }
            } elseif ($href = $this->modx->getOption('href', $meta)) {
                $size = (int)$this->modx->getOption('size', $meta);
                $limit = (int)$this->modx->getOption('limit', $meta);
                $offset = (int)$this->modx->getOption('offset', $meta);

                if ($size > ($offset + $limit)) {
                    $tmp = parse_url($href);
                    if (isset($tmp['query'])) {
                        parse_str($tmp['query'], $filters);
                        ksort($filters);
                        $filters['limit'] = $limit;
                        $filters['offset'] = $offset + $limit;
                    }
                }
            }

            /* $offset = (int)$this->modx->getOption('offset', $meta);
             if ($offset > 2000) {
                 $filters = array();
             }*/


            $this->setSyncPropertiesValue("sync_meta", $meta);
            $this->setSyncFilters($filters);
        }

        return $filters;
    }

    public function prepareExportValue($v = null, $type = 'string', $key = '')
    {
        switch (true) {
            case $type == 'boolean':
                $type = 'boolean';
                break;
            case $type == 'array':
                $type = 'string';
                break;

            case $key == 'name':
            case $key == 'description':
            case $key == 'article':
            case $key == 'code':
            case $key == 'externalCode':
                $type = 'string';
                break;
            case $key == 'weight':
            case $key == 'volume':
                $type = 'float';
                break;
            default:
                $type = 'string';
                break;
        }

        return $this->SyncTools->prepareValue($v, $type);

        /*
          switch ($type) {
              case 'array':
                  switch (true) {
                      case is_array($v):
                          $v = $this->Sync->cleanAndImplode($v);
                          break;
                  }
                  break;
              default:
                  break;
          }

          switch ($key) {
              case 'name':
              case 'description':
              case 'article':
              case 'code':
              case 'externalCode':
                  $v = (string)$v;
                  break;
              case 'weight':
              case 'volume':
                  $v = (float)$v;
                  break;
              default:
                  $v = (string)$v;
          }*/


        return $v;
    }

    /************************ PROCESS READ ************************/
    public function processSyncReadCurrency($row, $syncType, $syncAction)
    {
        $row = array_merge(array(
            "sync_parent" => $this->getSyncObjectUuid($row),
        ), $row);

        return $this->processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadCategory($row, $syncType, $syncAction)
    {
        $syncName = $this->modx->getOption('name', $row, "", true);
        $syncParent = $this->modx->getOption('pathName', $row, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        return $this->processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadProduct($row, $syncType, $syncAction)
    {
        $syncName = $this->modx->getOption('name', $row, "", true);
        $syncParent = $this->modx->getOption('pathName', $row, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadModification($row, $syncType, $syncAction)
    {
        $product = $this->modx->getOption('product', $row, array(), true);
        $syncParent = $this->getSyncObjectUuid($product);

        $classResource = "modResource";
        $q = $this->modx->newQuery($classResource);
        $q->where(array(
            "{$classResource}.sync_id"      => $syncParent,
            "{$classResource}.sync_service" => $this->syncService,
        ));
        $q->select("{$classResource}.id");

        if (!$syncResource = $this->modx->getValue($q->prepare())) {
            return null;
        };

        $row = array_merge(array(
            "sync_parent"   => $syncParent,
            "sync_resource" => $syncResource
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadStock($row, $syncType, $syncAction)
    {
        $folder = $this->modx->getOption('folder', $row, array(), true);
        $syncName = $this->modx->getOption('name', $folder, "", true);
        $syncParent = $this->modx->getOption('pathName', $folder, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "id"          => $this->getSyncObjectUuid($row),
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        $meta = $this->modx->getOption('meta', $row, array(), true);
        $type = $this->modx->getOption('type', $meta);
        if (!empty($type)) {
            $syncType = $type . "_" . $syncType;
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    /************************ PROCESS READ END ************************/


    /************************ PROCESS IMPORT ************************/

    public function prepareImportValue($v = null, $type = 'string')
    {
        switch (true) {
            case is_array($v) AND isset($v['meta']):
                $v = $v['name'];
                break;
        }

        return $this->SyncTools->prepareValue($v, $type);
    }

    public function prepareImportAttrValue($v = null, $type = 'string')
    {
        switch (true) {
            case is_array($v) AND isset($v['meta']):
                $v = $v['name'];
                break;
        }

        return $this->SyncTools->prepareValue($v, $type);
    }

    public function processSyncImportCategoryObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $classSync = "syncObject";
        $classResource = "modResource";

        $syncData = $this->modx->getOption('sync_data', $row);

        $name = $this->modx->getOption('name', $syncData);
        $syncParent = $this->modx->getOption('sync_parent', $row);

        if (!$this->getSyncResourceImportFolder($name, $syncParent)) {
            return null;
        }

        $row = array_merge(array(
            "pagetitle"             => $name,
            "parent"                => $this->getOption("sync_parent", null, 0, true),
            "class_key"             => $this->getOption("{$syncType}_class_key", null, "msCategory", true),
            "context_key"           => $this->getOption("{$syncType}_context_key", null, "web", true),
            "content_type"          => $this->getOption("{$syncType}_content_type", null, 1, true),
            "template"              => $this->getOption("{$syncType}_template", null, 1, true),
            "published"             => $this->getOption("{$syncType}_published", null, 1, true),
            "isfolder"              => $this->getOption("{$syncType}_isfolder", null, 1, true),
            "richtext"              => $this->getOption("{$syncType}_richtext", null, 1, true),
            "createdby"             => $this->getOption("{$syncType}_createdby", null, 1, true),
            "show_in_tree"          => $this->getOption("{$syncType}_show_in_tree", null, 1, true),
            "hide_children_in_tree" => $this->getOption("{$syncType}_hide_children_in_tree", null, 0, true),
        ), $row);


        /* set parent by $syncParent */
        if (!empty($syncParent)) {
            $q = $this->modx->newQuery($classSync);
            $q->innerJoin($classResource, $classResource,
                "{$classResource}.sync_id = {$classSync}.sync_id " .
                "AND {$classResource}.sync_service = {$classSync}.sync_service"
            );
            $q->where(array(
                "{$classSync}.sync_type"    => $syncType,
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncParent,
            ));
            $q->select("{$classResource}.id");
            if ($parent = $this->modx->getValue($q->prepare())) {
                $row["parent"] = $parent;
            };
        }

        $fields = $this->getOption('category_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }

        /* set published by $archived */
        $archived = (bool)$this->modx->getOption('archived', $syncData);
        if ($archived) {
            $row["published"] = $this->getOption("{$syncType}_archived_published", null, 0, true);
        }

        return $row;
    }

    public function processSyncImportUpdCategory($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportCategoryObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return $this->processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportCreCategory($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportCategoryObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return $this->processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportImage($row)
    {
        $image = null;
        if (isset($row['image'])) {
            $image = $this->SyncTools->getFile($row['image']);
            if (!empty($image)) {
                $image = array($image);
            }
        }

        return $image;
    }

    public function processSyncImportAttributes($row)
    {
        $data = array();
        $attributes = $this->modx->getOption('attributes', $row, array(), true);

        $fields = $this->getOption('product_attributes', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('name' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type);
            }
        }

        return $data;
    }


    public function processSyncImportServiceAttributes($row)
    {
        $data = array();
        $attributes = $this->modx->getOption('attributes', $row, array(), true);

        $fields = $this->getOption('service_attributes', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('name' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type);
            }
        }

        return $data;
    }


    public function processSyncImportPrice($row)
    {
        $data = array();

        $attributes = $this->modx->getOption('salePrices', $row, array(), true);
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('product_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('priceType' => $key));

            $currency = $this->Sync->getArrayValue($attributes, array('priceType' => $key), $key = 'currency');
            if (!is_null($value) AND is_array($currency)) {
                $rate = $this->getSyncResourcePriceRate($this->getSyncObjectUuid($currency));
            } else {
                $value = $this->modx->getOption('value', $v);
            }

            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type) / $rate;
            }
        }

        return $data;
    }

    public function processSyncImportServicePrice($row)
    {
        $data = array();

        $attributes = $this->modx->getOption('salePrices', $row, array(), true);
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('service_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('priceType' => $key));

            $currency = $this->Sync->getArrayValue($attributes, array('priceType' => $key), $key = 'currency');
            if (!is_null($value) AND is_array($currency)) {
                $rate = $this->getSyncResourcePriceRate($this->getSyncObjectUuid($currency));
            } else {
                $value = $this->modx->getOption('value', $v);
            }

            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type) / $rate;
            }
        }

        return $data;
    }


    public function processSyncImportProductObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $classSync = "syncObject";
        $classResource = "modResource";

        $syncData = $this->modx->getOption('sync_data', $row);

        $name = $this->modx->getOption('name', $syncData);
        $syncParent = $this->modx->getOption('sync_parent', $row);
        if (!$this->getSyncResourceImportFolder($name, $syncParent)) {
            return null;
        }

        $row = array_merge(array(
            "pagetitle"             => $name,
            "parent"                => $this->getOption("sync_parent", null, 0, true),
            "class_key"             => $this->getOption("{$syncType}_class_key", null, "msProduct", true),
            "context_key"           => $this->getOption("{$syncType}_context_key", null, "web", true),
            "content_type"          => $this->getOption("{$syncType}_content_type", null, 1, true),
            "template"              => $this->getOption("{$syncType}_template", null, 1, true),
            "published"             => $this->getOption("{$syncType}_published", null, 1, true),
            "isfolder"              => $this->getOption("{$syncType}_isfolder", null, 0, true),
            "richtext"              => $this->getOption("{$syncType}_richtext", null, 1, true),
            "createdby"             => $this->getOption("{$syncType}_createdby", null, 1, true),
            "show_in_tree"          => $this->getOption("{$syncType}_show_in_tree", null, 0, true),
            "hide_children_in_tree" => $this->getOption("{$syncType}_hide_children_in_tree", null, 0, true),
        ), $row);

        /* set parent by $syncParent */
        if (!empty($syncParent)) {
            $q = $this->modx->newQuery($classSync);
            $q->innerJoin($classResource, $classResource,
                "{$classResource}.sync_id = {$classSync}.sync_id " .
                "AND {$classResource}.sync_service = {$classSync}.sync_service"
            );
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncParent,
            ));
            $q->select("{$classResource}.id");
            if ($parent = $this->modx->getValue($q->prepare())) {
                $row["parent"] = $parent;
            };
        }

        /* process main fields */
        $fields = $this->getOption('product_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }


        /**********************************************************************/
        /* set country */
        $country = $this->modx->getOption('country', $syncData, array(), true);
        if (isset($country['name'])) {
            $row["made_in"] = $country['name'];
        }
        /* set published by $archived */
        $archived = (bool)$this->modx->getOption('archived', $syncData);
        if ($archived) {
            $row["published"] = $this->getOption("{$syncType}_archived_published", null, 0, true);
        }

        return $row;
    }


    public function processSyncImportServiceObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $classSync = "syncObject";
        $classResource = "modResource";

        $syncData = $this->modx->getOption('sync_data', $row);

        $name = $this->modx->getOption('name', $syncData);
        $syncParent = $this->modx->getOption('sync_parent', $row);
        if (!$this->getSyncResourceImportFolder($name, $syncParent)) {
            return null;
        }

        $row = array_merge(array(
            "pagetitle"             => $name,
            "parent"                => $this->getOption("sync_parent", null, 0, true),
            "class_key"             => $this->getOption("{$syncType}_class_key", null, "msProduct", true),
            "context_key"           => $this->getOption("{$syncType}_context_key", null, "web", true),
            "content_type"          => $this->getOption("{$syncType}_content_type", null, 1, true),
            "template"              => $this->getOption("{$syncType}_template", null, 1, true),
            "published"             => $this->getOption("{$syncType}_published", null, 1, true),
            "isfolder"              => $this->getOption("{$syncType}_isfolder", null, 0, true),
            "richtext"              => $this->getOption("{$syncType}_richtext", null, 1, true),
            "createdby"             => $this->getOption("{$syncType}_createdby", null, 1, true),
            "show_in_tree"          => $this->getOption("{$syncType}_show_in_tree", null, 0, true),
            "hide_children_in_tree" => $this->getOption("{$syncType}_hide_children_in_tree", null, 0, true),
        ), $row);

        /* set parent by $syncParent */
        if (!empty($syncParent)) {
            $q = $this->modx->newQuery($classSync);
            $q->innerJoin($classResource, $classResource,
                "{$classResource}.sync_id = {$classSync}.sync_id " .
                "AND {$classResource}.sync_service = {$classSync}.sync_service"
            );
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncParent,
            ));
            $q->select("{$classResource}.id");
            if ($parent = $this->modx->getValue($q->prepare())) {
                $row["parent"] = $parent;
            };
        }

        /* process main fields */
        $fields = $this->getOption('service_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }


        /**********************************************************************/
        /* set published by $archived */
        $archived = (bool)$this->modx->getOption('archived', $syncData);
        if ($archived) {
            $row["published"] = $this->getOption("{$syncType}_archived_published", null, 0, true);
        }

        return $row;
    }

    public function processSyncImportUpdProduct($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('product_process_attributes_on_import')) {
            $attributes = $this->processSyncImportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_image') AND $this->getOption('product_process_image_on_import_upd')) {
            $row["sync_images"] = $this->processSyncImportImage($syncData);
        }

        if ($this->getOption('process_price') AND $this->getOption('product_process_price_on_import_upd')) {
            $price = $this->processSyncImportPrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportCreProduct($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('product_process_attributes_on_import')) {
            $attributes = $this->processSyncImportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_image') AND $this->getOption('product_process_image_on_import_cre')) {
            $row["sync_images"] = $this->processSyncImportImage($syncData);
        }

        if ($this->getOption('process_price') AND $this->getOption('product_process_price_on_import_cre')) {
            $price = $this->processSyncImportPrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportUpdService($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportServiceObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('service_process_attributes_on_import')) {
            $attributes = $this->processSyncImportServiceAttributes($syncData);
            $row = array_merge($row, $attributes);
        }


        if ($this->getOption('process_price') AND $this->getOption('service_process_price_on_import_upd')) {
            $price = $this->processSyncImportServicePrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportCreService($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportServiceObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('service_process_attributes_on_import')) {
            $attributes = $this->processSyncImportServiceAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('service_process_price_on_import_cre')) {
            $price = $this->processSyncImportServicePrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportModification($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $syncResource = (int)$this->modx->getOption('sync_resource', $row);

        $modification = array(
            'sync_id'      => $this->modx->getOption('sync_id', $row),
            'sync_service' => $this->modx->getOption('sync_service', $row)
        );

        /* process main fields */
        $fields = $this->getOption('modification_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $modification[$k] = $this->prepareImportValue($value, $type);
            }
        }

        /* process characteristics */
        if (!$characteristics = $this->modx->getOption('characteristics', $syncData)) {
            return null;
        }

        $options = array();
        $fields = $this->getOption('modification_characteristics', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($characteristics, array('name' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $options[$k] = $this->prepareImportAttrValue($value, $type);
            }
        }

        if (empty($options)) {
            return null;
        }
        $modification['options'] = $options;

        /* process price */
        $prices = $this->modx->getOption('salePrices', $syncData, array(), true);
        $rate = $this->getSyncResourcePriceRate();
        $fields = $this->getOption('modification_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($prices, array('priceType' => $key));

            $currency = $this->Sync->getArrayValue($prices, array('priceType' => $key), $key = 'currency');
            if (!is_null($value) AND is_array($currency)) {
                $rate = $this->getSyncResourcePriceRate($this->getSyncObjectUuid($currency));
            } else {
                $value = $this->modx->getOption('value', $v);
            }

            if (!is_null($value)) {
                $modification[$k] = $this->prepareImportAttrValue($value, $type) / $rate;
            }
        }

        /* fix empty salePrices */
        if (empty($prices) AND empty($modification['price'])) {
            if ($po = $this->modx->getObject('msProduct', $syncResource)) {
                $modification['price'] = $po->get('price');
            }
        }

        return parent::processSyncObject($modification, $syncType, $syncAction);
    }

    public function processSyncImportProductStockObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $fields = $this->getOption('product_stock', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }

        return $row;
    }


    public function processSyncImportUpdProductStock($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductStockObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportModificationStockObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $stock = array();
        $fields = $this->getOption('modification_stock', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $stock[$k] = $this->prepareImportValue($value, $type);
            }
        }

        return $stock;
    }

    public function processSyncImportUpdModificationStock($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $syncResourceId = (int)$this->modx->getOption('sync_resource', $row);
        $syncModificationId = (int)$this->modx->getOption('sync_modification', $row);

        if (!$ro = $this->modx->getObject('modResource', $syncResourceId)) {
            return null;
        }
        $row["sync_id"] = $ro->get('sync_id');

        if (!$stock = $this->processSyncImportModificationStockObject($row, $syncType, $syncAction)) {
            return null;
        }

        $stock = array_merge($stock, array(
            'id'  => $syncModificationId,
            'rid' => $syncResourceId,
        ));

        $row["sync_modification_stock"] = $stock;

        return parent::processSyncObject($row, $syncType, $syncAction);
    }
    /************************ PROCESS IMPORT END ************************/


    /************************ PROCESS EXPORT ************************/
    public function prepareExportAttrValue($v = null, $type = 'string', $key = '')
    {
        $syncType = "product_metadata_attribute";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_service" => $this->syncService,
            "{$classSync}.sync_parent"  => $key,
        ));
        $q->limit(1);

        $value = null;
        if ($o = $this->modx->getObject($classSync, $q)) {
            $syncId = $o->get('sync_id');
            $syncData = $o->get('sync_data');

            $attrType = $this->modx->getOption('type', $syncData);
            switch ($attrType) {
                case 'customentity':
                    $v = $this->prepareExportValue($v, $type, $key);
                    if (!empty($v)) {
                        $value = array(
                            "id"    => $syncId,
                            "value" => array(
                                "name" => $v
                            )
                        );
                    }
                    break;
                default:
                    $v = $this->prepareExportValue($v, $type, $key);
                    $value = array(
                        "id"    => $syncId,
                        "name"  => $key,
                        "value" => $v
                    );
                    break;
            }
        }

        /*
         * $q->select('sync_id');
         * if ($stmt = $q->prepare() AND $syncId = $this->modx->getValue($stmt)) {
            $v = array(
                "id"    => $syncId,
                "name"  => $key,
                "value" => $this->prepareExportValue($v, $type, $key)
            );
        } else {
            $v = null;
        }*/

        return $value;
    }

    public function prepareExportCharValue($v = null, $type = 'string', $key = '')
    {
        $syncType = "modification_metadata_characteristic";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_service" => $this->syncService,
            "{$classSync}.sync_parent"  => $key,
        ));
        $q->limit(1);

        $q->select('sync_id');
        if ($stmt = $q->prepare() AND $syncId = $this->modx->getValue($stmt)) {
            $v = array(
                "id"    => $syncId,
                "value" => $this->prepareExportValue($v, $type, $key)
            );
        } else {
            $v = null;
        }

        return $v;
    }

    public function processSyncExportImage($row)
    {
        $image = null;
        if (isset($row['image'])) {
            $image = $this->SyncTools->setFile($row['image']);
        }

        return $image;
    }

    public function processSyncExportAttributes($row)
    {
        $attributes = $set = array();

        $fields = $this->getOption('product_attributes', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!empty($set[$key])) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportAttrValue($value, $type, $key);
            if (!is_null($value)) {
                $attributes[] = $set[$key] = $value;
            }
        }

        return array('attributes' => $attributes);
    }

    public function processSyncExportServiceAttributes($row)
    {
        $attributes = $set = array();

        $fields = $this->getOption('service_attributes', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!empty($set[$key])) {
                continue;
            }
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportAttrValue($value, $type, $key);
            if (!is_null($value)) {
                $attributes[] = $set[$key] = $value;
            }
        }

        return array('attributes' => $attributes);
    }

    public function processSyncExportPrice($row)
    {
        $data = array();
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('product_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $tmp = array(
                    "value"     => (float)$value * $rate,
                    "priceType" => $key
                );
                $currency = $this->getSyncResourceCurrencySyncMeta();
                if (!empty($currency)) {
                    $tmp["currency"] = array("meta" => $currency);
                }
                $data[] = $tmp;
            }
        }

        return array('salePrices' => $data);
    }

    public function processSyncExportServicePrice($row)
    {
        $data = array();
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('service_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $tmp = array(
                    "value"     => (float)$value * $rate,
                    "priceType" => $key
                );
                $currency = $this->getSyncResourceCurrencySyncMeta();
                if (!empty($currency)) {
                    $tmp["currency"] = array("meta" => $currency);
                }
                $data[] = $tmp;
            }
        }

        return array('salePrices' => $data);
    }


    public function processSyncExportCharacteristics($row)
    {
        $attributes = array();

        $fields = $this->getOption('modification_characteristics', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportCharValue($value, $type, $key);
            if (!is_null($value)) {
                $attributes[] = $value;
            }
        }

        return array('characteristics' => $attributes);
    }

    public function processSyncExportModificationPrice($row)
    {
        $data = array();
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('modification_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $data[] = array(
                    "value"     => (float)$value * $rate,
                    "priceType" => $key
                );
            }
        }

        return array('salePrices' => $data);
    }

    public function processSyncExportUnlCategory($row, $syncType, $syncAction)
    {
        $row = array_merge(array(
            "sync_resource" => $this->modx->getOption('id', $row),
        ), $row);

        $row["sync_data"] = array();

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportUnlProduct($row, $syncType, $syncAction)
    {
        $row = array_merge(array(
            "sync_resource" => $this->modx->getOption('id', $row),
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportCreCategory($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description');
        $fields = $this->getOption('category_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportCreProduct($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
            "article"     => (string)$this->modx->getOption('article', $row,
                $this->modx->getOption('article', $syncData)),
            "weight"      => (float)$this->modx->getOption('weight', $row, $this->modx->getOption('weight', $syncData)),
            "volume"      => (float)$this->modx->getOption('volume', $row, $this->modx->getOption('volume', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description', 'article', 'code', 'externalCode', 'weight', 'volume');
        $fields = $this->getOption('product_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        /* check code */
        if (isset($row['code']) AND empty($row['code'])) {
            unset($row['code']);
        }

        if ($this->getOption('product_process_attributes_on_export')) {
            $attributes = $this->processSyncExportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_image') AND $this->getOption('product_process_image_on_export_cre')) {
            $row["image"] = $this->processSyncExportImage($syncData);
        }

        if ($this->getOption('process_price') AND $this->getOption('product_process_price_on_export_cre')) {
            $price = $this->processSyncExportPrice($syncData);
            $row = array_merge($row, $price);
        }

        if ($this->getOption('compatibility_1c', null)) {
            $row = $this->processSyncResourceCompatibility1c($row, $syncType, $syncData);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }


    public function processSyncResourceCompatibility1c($row, $syncType, $syncData)
    {
        if (is_array($row)) {

            if (empty($row['code'])) {
                $codePrefix = $this->getOption('code_prefix', null, 'code_');
                $row['code'] = $codePrefix;
                $row['code'] .= !empty($syncData['id']) ? $syncData['id'] : time();
            }

            if (isset($row['name'])) {
                $row['name'] = mb_substr($row['name'], 0, 100, 'utf-8');
            }
            if (isset($row['article'])) {
                $row['article'] = mb_substr($row['article'], 0, 25, 'utf-8');
            }
            if (isset($row['code'])) {
                $row['code'] = mb_substr($row['code'], 0, 11, 'utf-8');
            }
        }

        return $row;
    }

    public function processSyncExportCreService($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
            "article"     => (string)$this->modx->getOption('article', $row,
                $this->modx->getOption('article', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description', 'article', 'code', 'externalCode');
        $fields = $this->getOption('service_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        /* check code */
        if (isset($row['code']) AND empty($row['code'])) {
            unset($row['code']);
        }

        if ($this->getOption('service_process_attributes_on_export')) {
            $attributes = $this->processSyncExportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('service_process_price_on_export_cre')) {
            $price = $this->processSyncExportServicePrice($syncData);
            $row = array_merge($row, $price);
        }

        if ($this->getOption('compatibility_1c', null)) {
            $row = $this->processSyncResourceCompatibility1c($row, $syncType, $syncData);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportUpdProduct($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
            "article"     => (string)$this->modx->getOption('article', $row,
                $this->modx->getOption('article', $syncData)),
            "weight"      => (float)$this->modx->getOption('weight', $row, $this->modx->getOption('weight', $syncData)),
            "volume"      => (float)$this->modx->getOption('volume', $row, $this->modx->getOption('volume', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description', 'article', 'code', 'externalCode', 'weight', 'volume');
        $fields = $this->getOption('product_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        /* check code */
        if (isset($row['code']) AND empty($row['code'])) {
            unset($row['code']);
        }

        if ($this->getOption('product_process_attributes_on_export')) {
            $attributes = $this->processSyncExportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_image') AND $this->getOption('product_process_image_on_export_upd')) {
            $row["image"] = $this->processSyncExportImage($syncData);
        }

        if ($this->getOption('process_price') AND $this->getOption('product_process_price_on_export_upd')) {
            $price = $this->processSyncExportPrice($syncData);
            $row = array_merge($row, $price);
        }

        if ($this->getOption('compatibility_1c', null)) {
            $row = $this->processSyncResourceCompatibility1c($row, $syncType, $syncData);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportUpdService($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
            "article"     => (string)$this->modx->getOption('article', $row,
                $this->modx->getOption('article', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description', 'article', 'code', 'externalCode');
        $fields = $this->getOption('service_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        /* check code */
        if (isset($row['code']) AND empty($row['code'])) {
            unset($row['code']);
        }

        if ($this->getOption('service_process_attributes_on_export')) {
            $attributes = $this->processSyncExportServiceAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('service_process_price_on_export_upd')) {
            $price = $this->processSyncExportServicePrice($syncData);
            $row = array_merge($row, $price);
        }

        if ($this->getOption('compatibility_1c', null)) {
            $row = $this->processSyncResourceCompatibility1c($row, $syncType, $syncData);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportUnlModification($row, $syncType, $syncAction)
    {
        return parent::processSyncObject($row, $syncType, $syncAction);
    }


    public function processSyncExportUpdModification($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $product = $this->modx->getOption('product', $row);

        $row = array(
            "name" => (string)$this->modx->getOption('name', $syncData),
            "code" => (string)$this->modx->getOption('article', $syncData)
        );
        if (is_array($product)) {
            $row['product'] = $product;
        }

        $allowedFields = array(
            'name',
            'code',
            'externalCode',
            'characteristics',
            'buyPrice',
            'salePrices',
            'minPrice',
            'product'
        );
        $fields = $this->getOption('modification_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        /* check code */
        if (isset($row['code']) AND empty($row['code'])) {
            unset($row['code']);
        }

        if ($this->getOption('modification_process_char_on_export')) {
            $syncOptions = $this->modx->getOption('options', $syncData, array(), true);
            $characteristics = $this->processSyncExportCharacteristics($syncOptions);
            $row = array_merge($row, $characteristics);
        }

        if ($this->getOption('process_price') AND $this->getOption('modification_process_price_on_export')) {
            $price = $this->processSyncExportModificationPrice($syncData);
            $row = array_merge($row, $price);
        }

        if ($this->getOption('compatibility_1c', null)) {
            $row = $this->processSyncResourceCompatibility1c($row, $syncType, $syncData);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportCreModification($row, $syncType, $syncAction)
    {
        $syncResource = (int)$this->modx->getOption('sync_resource', $row);
        $syncMeta = null;
        if ($po = $this->modx->getObject('modResource', $syncResource)) {
            $syncData = $po->get('sync_data');
            $syncMeta = $this->modx->getOption('meta', $syncData);
        }
        if (empty($syncMeta)) {
            return null;
        }
        $row['product'] = array('meta' => $syncMeta);

        return $this->processSyncExportUpdModification($row, $syncType, $syncAction);
    }

    /************************ PROCESS EXPORT END ************************/


    public function processSyncObjectError(syncObject $object, $data = array(), $row = array())
    {
        return $this->SyncTools->processSyncObjectError($object, $data, $row);
    }

}

return 'modSyncMoySkladMsCategoryBaseProcessor';