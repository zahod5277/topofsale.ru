<?php

require_once dirname(__FILE__) . '/sync.class.php';

class modSyncMoySkladImportProcessor extends modSyncMoySkladSyncProcessor
{
    /**
     * @var array
     */
    protected $steps = array(
        "sync_init",
        //
        "sync_read_currency",
        "sync_read_category",
        //
        "sync_set_sync_category",
        //
        "sync_import_upd_category",
        "sync_import_cre_category",
        //
        "sync_read_product_metadata",
        "sync_read_product",
        //
        "sync_import_upd_product",
        "sync_import_cre_product",
        //
        "sync_read_modification_metadata",
        "sync_read_modification",
        //
        "sync_import_upd_modification",
        //
        "sync_read_store",
        "sync_read_stock",
        //
        "sync_import_upd_product_stock",
        "sync_import_upd_modification_stock",

        //
        "sync_read_service_metadata",
        "sync_read_service",
        //
        "sync_import_upd_service",
        "sync_import_cre_service",
        //

        "sync_close",
    );

}

return 'modSyncMoySkladImportProcessor';