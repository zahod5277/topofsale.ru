<?php

//ini_set('display_errors', 1);
//ini_set('error_reporting', -1);

if (!class_exists('SyncTools')) {
    /** @noinspection PhpIncludeInspection */
    //require_once dirname(__FILE__) . '/synctools.class.php';

    require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/sync/tools/synctools.class.php';
}

class SyncMoySkladTools extends SyncTools
{

    /** @var mixed|null $syncService */
    protected $syncService = 'moysklad';

    /**
     * Methods
     */
    public static $METHOD_GET = 'GET';
    public static $METHOD_POST = 'POST';
    public static $METHOD_PUT = 'PUT';
    public static $METHOD_DELETE = 'DELETE';


    /**
     * Filters
     */
    public static $FILTER_OPERANDS = array('=', '>', '<', '>=', '<=', '!=');

    public static $REQUEST_ATTRIBUTES_MAIN = array('metadata', 'all', 'bystore', 'byoperation');
    public static $REQUEST_ATTRIBUTES_SECOND = array(
        'accounts',
        'contactpersons',
        'packs',
        'cashiers',
        'positions'
    );

    /**
     * Restrictions
     */
    public static $MAX_DATA_VALUE = 10485760;//10 * 1024 * 1024;


    protected $timeout = 30;
    protected $retry;

    protected $entity = array(
        "counterparty"    => "entity",
        "consignment"     => "entity",
        "currency"        => "entity",
        "productFolder"   => "entity",
        "service"         => "entity",
        "product"         => "entity",
        "contract"        => "entity",
        "variant"         => "entity",
        "project"         => "entity",
        "state"           => "entity",
        "employee"        => "entity",
        "store"           => "entity",
        "organization"    => "entity",
        "retailshift"     => "entity",
        "retailstore"     => "entity",
        "cashier"         => "entity",
        "customerOrder"   => "entity",
        "demand"          => "entity",
        "invoiceout"      => "entity",
        "retaildemand"    => "entity",
        "purchaseOrder"   => "entity",
        "supply"          => "entity",
        "invoicein"       => "entity",
        "paymentin"       => "entity",
        "paymentout"      => "entity",
        "cashin"          => "entity",
        "cashout"         => "entity",
        "companysettings" => "entity",
        "expenseItem"     => "entity",
        "country"         => "entity",
        "uom"             => "entity",
        "customentity"    => "entity",
        "salesreturn"     => "entity",
        "purchasereturn"  => "entity",
        "webhook"         => "entity",

        "stock"      => "report",
        "assortment" => "pos",
        "openshift"  => "pos",
        "closeshift" => "pos"
    );

    public function __construct(modX $modx, &$config)
    {
        parent::__construct($modx, $config);

        $this->retry = 0;
    }


    public function getData(
        $options,
        $filters = null
    ) {

        if (empty($options)) {
            throw new \InvalidArgumentException('The `params` can not be empty');
        }
        $uri = $this->entity[reset($options)] . '/';
        foreach ($options as $option) {
            $uri .= $option . '/';
        }
        unset($option);

        $uri = trim($uri, '/');
        $limit = $this->getOption('api_limit', null, 50);

        switch (count($options)) {
            case 1:
                $filters['limit'] = (!empty($filters['limit'])) ? $filters['limit'] : $limit;
                $filters['offset'] = (!empty($filters['offset'])) ? $filters['offset'] : 0;
                $filters['filters'] = (!empty($filters['filters'])) ? $filters['filters'] : null;
                break;
            case 2:
                if (!in_array($options[1], self::$REQUEST_ATTRIBUTES_MAIN)) {
                    $this->checkUuid($options[1]);
                }
                $filters['limit'] = (!empty($filters['limit'])) ? $filters['limit'] : $limit;
                $filters['offset'] = (!empty($filters['offset'])) ? $filters['offset'] : 0;
                $filters['filters'] = (!empty($filters['filters'])) ? $filters['filters'] : null;
                break;
            case 3:
                $this->checkUuid($options[1]);
                if (!in_array($options[2], self::$REQUEST_ATTRIBUTES_SECOND)) {
                    throw new \InvalidArgumentException(sprintf('Wrong attribute: `%s`', $options[2]));
                }
                break;
            case 4:
                $this->checkUuid($options[1]);
                if (!in_array($options[2], self::$REQUEST_ATTRIBUTES_SECOND)) {
                    throw new \InvalidArgumentException(sprintf('Wrong attribute: `%s`', $options[2]));
                }
                $this->checkUuid($options[3]);
                break;
        }

        //print_r($uri);print_r($filters);die;

        return $this->makeRequest(
            $uri,
            self::$METHOD_GET,
            $filters
        );
    }

    public function createData($option, $data)
    {
        if (is_array($option)) {
            $type = $option[0];
            $uuid = $option[1];
            $this->checkUuid($uuid);
        } else {
            $type = $option;
            $uuid = null;
        }
        $parameters['data'] = $data;

        return $this->makeRequest(
            $this->entity[$type] . '/' . $type . (!is_null($uuid) ? ('/' . $uuid) : ''),
            self::$METHOD_POST,
            $parameters
        );
    }

    public function updateData($type, $uuid, $data)
    {
        $this->checkUuid($uuid);
        $parameters['data'] = $data;

        return $this->makeRequest(
            sprintf($this->entity[$type] . '/' . $type . '/%s', $uuid),
            self::$METHOD_PUT,
            $parameters
        );
    }

    public function deleteData($type, $uuid)
    {
        $this->checkUuid($uuid);

        return $this->makeRequest(
            sprintf($this->entity[$type] . '/' . $type . '/%s', $uuid),
            self::$METHOD_DELETE
        );
    }


    public function makeRequest(
        $url,
        $method = 'GET',
        array $parameters = array()
    ) {
        time_nanosleep(0, 250000000);
        $allowedMethods = array(self::$METHOD_GET, self::$METHOD_POST, self::$METHOD_PUT, self::$METHOD_DELETE);
        if (!in_array($method, $allowedMethods, false)) {
            throw new \InvalidArgumentException(
                sprintf(
                    'Method "%s" is not valid. Allowed methods are %s',
                    $method,
                    implode(', ', $allowedMethods)
                )
            );
        }

        if (strpos($url, $this->getOption('api_endpoint')) === false) {
            $curlUrl = $this->getOption('api_endpoint') . '/' . $url;
        } else {
            $curlUrl = $url;
        }

        $apiUser = $this->getOption('api_user');
        $apiPassword = $this->getOption('api_password');

        if ($method === self::$METHOD_GET AND count($parameters)) {
            $curlUrl .= $this->httpBuildQuery($parameters);
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERPWD, "{$apiUser}:{$apiPassword}");
        curl_setopt($ch, CURLOPT_URL, $curlUrl);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout);
        if (
            !is_null($parameters) AND
            in_array($method, array(self::$METHOD_POST, self::$METHOD_PUT)) AND
            !empty($parameters['data'])
        ) {
            /* проверка размера POST */
            if (strlen(json_encode($parameters['data'])) > self::$MAX_DATA_VALUE) {
                $this->log("[" . __CLASS__ . "] The POST data size should not exceed: " . self::$MAX_DATA_VALUE, true);

                return new ApiResponse('404', null);
            }

            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json'
            ));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters['data']));
            if ($method == self::$METHOD_PUT) {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            }
            if ($method == self::$METHOD_POST) {
                curl_setopt($ch, CURLOPT_POST, true);
            }
        }
        if (in_array($method, array(self::$METHOD_DELETE))) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json'
            ));
        }
        $responseBody = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        curl_close($ch);
        if ($statusCode >= 400) {
            $result = json_decode($responseBody, true);
            $this->log($statusCode, $this->getError($result));
        }
        if ($errno AND in_array($errno, array(6, 7, 28, 34, 35)) AND $this->retry < 3) {
            $errno = null;
            $error = null;
            $this->retry += 1;
            $this->makeRequest(
                $url,
                $method,
                $parameters
            );
        }
        if ($errno) {
            throw new RuntimeException($error, $errno);
        }

        return new ApiResponse($statusCode, $responseBody);
    }

    private function httpBuildQuery($parameters)
    {
        $params = array();
        $filter = '';
        $filters = array();
        if (is_array($parameters)) {
            foreach ($parameters as $name => $value) {
                if (preg_match('/^\d+$/', $name)) {
                    $filter .= '&' . (string)$value;
                    continue;
                } elseif ($name == 'filters') {
                    if (!empty($value) & is_array($value)) {
                        $filter .= '&' . $this->buildFilter($value);
                    }
                    continue;
                }
                $filters[$name] = $value;
            }
            unset($name, $value);
            $params = array_merge($params, $filters);
        }

        return '?' . http_build_query($params) . $filter;
    }

    private function buildFilter($filters)
    {
        $params = '';
        foreach ($filters as $filter) {
            if (!in_array($filter['operand'], self::$FILTER_OPERANDS)) {
                continue;
            }
            $params .= $filter['name'] . $filter['operand'] . $filter['value'] . ';';
        }
        unset($filter);
        $params = trim($params, ';');

        return 'filter=' . $params;
    }

    private function getError($result)
    {
        $error = "";
        if (!empty($result['errors'])) {
            foreach ($result['errors'] as $err) {
                if (!empty($err['parameter'])) {
                    $error .= "[" . date("Y-m-d H:i:s") . "] Error " . $err['parameter'] . ": " . $err['error'] . "\n";
                } else {
                    $error .= "[" . date("Y-m-d H:i:s") . "] Error: " . $err['error'] . "\n";
                }
            }
        } else {
            $error = "[" . date("Y-m-d H:i:s") . "] Internal server error";
        }

        return $error;
    }

    private function checkUuid($uuid)
    {
        if (is_null($uuid) OR empty($uuid)) {
            throw new \InvalidArgumentException('The `uuid` can not be empty');
        }
        if (!preg_match("#^[\w\d]{8}-[\w\d]{4}-[\w\d]{4}-[\w\d]{4}-[\w\d]{12}$#", $uuid)) {
            if (preg_match("#^[a-z\d]+$#i", $uuid)) {
                throw new \InvalidArgumentException(sprintf('Wrong attribute: `%s`', $uuid));
            }
            throw new \InvalidArgumentException('The `uuid` has invalid format');
        }
    }

    public function getUuidByMeta($meta)
    {
        $uuid = null;
        $href = isset($meta['href']) ? $meta['href'] : '';
        $uuid = pathinfo(parse_url($href, PHP_URL_PATH), PATHINFO_FILENAME);

        return $uuid;
    }

    public function getFile($params = array())
    {
        $file = null;
        $meta = $this->modx->getOption('meta', $params, array(), true);
        if ($href = $this->modx->getOption('href', $meta)) {

            $dir = $this->getTempDir($params);
            $filename = $this->modx->getOption('filename', $params, md5(serialize($params)), true);
            $file = $dir . $filename;

            if (!file_exists($file)) {
                $response = $this->makeRequest(
                    $href,
                    self::$METHOD_GET
                );

                if ($response->isSuccessful()) {
                    $image = $response->getResponseBody();

                    if (!file_put_contents($file, $image)) {
                        $file = null;
                        $this->log("[" . __CLASS__ . "] Could not save file:", $file, true);
                    }
                }
            }
        }

        return $file;
    }

    public function setFile($file)
    {
        if (!empty($file) AND $content = @file_get_contents(MODX_BASE_PATH . $file)) {
            return array(
                "filename" => basename($file),
                "content"  => base64_encode($content)
            );
        }

        return null;
    }

    public function getWebHook(array $row = array())
    {
        $response = $this->runProcessor('system/hook', array("sync_step" => "sync_get_web_hook", "row" => $row), '',
            false);

        return isset($response['data']) ? $response['data'] : array();
    }

    public function setWebHook(array $row = array())
    {
        $response = $this->runProcessor('system/hook', array("sync_step" => "sync_set_web_hook", "row" => $row), '',
            false);

        return isset($response['data']) ? $response['data'] : array();
    }

    public function updWebHook(array $row = array())
    {
        $response = $this->runProcessor('system/hook', array("sync_step" => "sync_upd_web_hook", "row" => $row), '',
            false);

        return isset($response['data']) ? $response['data'] : array();
    }

    public function delWebHook(array $row = array())
    {
        $response = $this->runProcessor('system/hook', array("sync_step" => "sync_del_web_hook", "row" => $row), '',
            false);

        return isset($response['data']) ? $response['data'] : array();
    }

}


/**
 * Response from MoySklad API
 *
 * @link     https://online.moysklad.ru/api/remap/1.1/doc/index.html
 */
class ApiResponse implements \ArrayAccess
{
    // HTTP response status code
    protected $statusCode;
    // response assoc array
    protected $response;

    /**
     * ApiResponse constructor.
     *
     * @param int   $statusCode HTTP status code
     * @param mixed $responseBody HTTP body
     *
     * @throws InvalidJsonException
     */
    public function __construct($statusCode, $responseBody = null)
    {
        $this->statusCode = (int)$statusCode;
        if (!empty($responseBody)) {
            if (strpos($responseBody, '{') === 0) {
                $response = json_decode($responseBody, true);
                if (!$response && JSON_ERROR_NONE !== ($error = json_last_error())) {

                    var_dump($responseBody);
                    throw new DomainException(
                        "Invalid JSON in the API response body. Error code #$error",
                        $error
                    );
                }
            } else {
                $response = $responseBody;
            }

            $this->response = $response;
        }
    }

    /**
     * Return HTTP response status code
     *
     * @return int
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }

    /**
     * Return HTTP response body
     *
     * @return array
     */
    public function getResponseBody()
    {
        /*if (!$this->isSuccessful()) {
            throw new Exception("MoySklad return \"{$this->getStatusCode()}\" status code");
        }*/

        return $this->response;
    }

    /**
     * HTTP request was successful
     *
     * @return bool
     */
    public function isSuccessful()
    {
        return $this->statusCode < 400;
    }

    /**
     * Allow to access for the property throw class method
     *
     * @param string $name method name
     * @param mixed  $arguments method parameters
     *
     * @throws \InvalidArgumentException
     *
     * @return mixed
     */
    public function __call($name, $arguments)
    {
        // convert getSomeProperty to someProperty
        $propertyName = strtolower(substr($name, 3, 1)) . substr($name, 4);
        if (!isset($this->response[$propertyName])) {
            throw new \InvalidArgumentException("Method \"$name\" not found");
        }

        return $this->response[$propertyName];
    }

    /**
     * Allow to access for the property throw object property
     *
     * @param string $name property name
     *
     * @throws \InvalidArgumentException
     *
     * @return mixed
     */
    public function __get($name)
    {
        if (!isset($this->response[$name])) {
            throw new \InvalidArgumentException("Property \"$name\" not found");
        }

        return $this->response[$name];
    }

    /**
     * Offset set
     *
     * @param mixed $offset offset
     * @param mixed $value value
     *
     * @throws \BadMethodCallException
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        throw new \BadMethodCallException('This activity not allowed');
    }

    /**
     * Offset unset
     *
     * @param mixed $offset offset
     *
     * @throws \BadMethodCallException
     * @return void
     */
    public function offsetUnset($offset)
    {
        throw new \BadMethodCallException('This call not allowed');
    }

    /**
     * Check offset
     *
     * @param mixed $offset offset
     *
     * @return bool
     */
    public function offsetExists($offset)
    {
        return isset($this->response[$offset]);
    }

    /**
     * Get offset
     *
     * @param mixed $offset offset
     *
     * @throws \InvalidArgumentException
     *
     * @return mixed
     */
    public function offsetGet($offset)
    {
        if (!isset($this->response[$offset])) {
            throw new \InvalidArgumentException("Property \"$offset\" not found");
        }

        return $this->response[$offset];
    }
}
