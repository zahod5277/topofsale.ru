<?php

include_once 'setting.inc.php';

$_lang['sync_moysklad'] = 'Мой Склад';


// step sync
//$_lang['sync_step_sync_set_sync_category'] = 'Установка корневой категории синхронизации';
