<?php

require_once dirname(__FILE__) . '/sync.class.php';

class modSyncMoySkladExportProcessor extends modSyncMoySkladSyncProcessor
{
    /**
     * @var array
     */

    protected $steps = array(
        "sync_init",
        //
        "sync_read_currency",
        "sync_read_category",
        //
        "sync_set_sync_category",
        //
        "sync_read_product_metadata",
        //
        "sync_read_modification_metadata",
        //
        "sync_read_service_metadata",
        //

        "sync_export_unl_category",
        "sync_export_upd_category",
        "sync_export_unl_new_category",
        "sync_export_cre_category",
        //
        "sync_export_unl_product",
        "sync_export_upd_product",
        "sync_export_unl_new_product",
        "sync_export_cre_product",
        //
        "sync_export_unl_modification",
        "sync_export_upd_modification",
        "sync_export_unl_new_modification",
        "sync_export_cre_modification",
        //
        "sync_export_unl_service",
        "sync_export_upd_service",
        "sync_export_unl_new_service",
        "sync_export_cre_service",

        "sync_close",
    );

}

return 'modSyncMoySkladExportProcessor';