<?php

/** @var array $scriptProperties */
/** @var Sync $Sync */
$corePath = $modx->getOption('sync_core_path', null,
    $modx->getOption('core_path', null, MODX_CORE_PATH) . 'components/sync/');
if (!$Sync = $modx->getService('sync', 'Sync', $corePath . 'model/sync/',
    array('core_path' => $corePath))
) {
    return;
}

$service = 'moysklad';
if (!$Sync->loadSyncTools($service)) {
    return;
}

switch ($modx->event->name) {

    case 'syncOnSyncObjectProcess':
        /** @var xPDOObject $object */
        $object = $modx->getOption('object', $scriptProperties, null, true);
        if (
            !$object
            OR
            !$Sync->isSyncObject($object, $service)
        ) {
            return;
        }

        $syncType = $object->get('sync_type');
        $syncAction = $object->get('sync_action');
        $classKey = $object->get('class_key');

        //$modx->log(1, print_r( $object->toArray(),1));

        switch (true) {
            /* hook event */
            case $classKey == 'event' AND $syncType == 'product' AND $syncAction == 'update':
                break;
            case $classKey == 'event' AND $syncType == 'product' AND $syncAction == 'delete':
            case $classKey == 'event' AND $syncType == 'service' AND $syncAction == 'delete':
            case $classKey == 'event' AND $syncType == 'productfolder' AND $syncAction == 'delete':
                $Sync->SyncTools->processSyncResourceDeleted($object);
                break;
        }

        break;

}
