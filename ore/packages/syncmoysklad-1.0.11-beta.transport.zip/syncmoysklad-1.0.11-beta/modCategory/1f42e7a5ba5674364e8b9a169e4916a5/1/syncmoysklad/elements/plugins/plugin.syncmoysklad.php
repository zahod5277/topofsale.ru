<?php

/** @var array $scriptProperties */
/** @var syncMoySklad $syncMoySklad */
$corePath = $modx->getOption('sync_moysklad_core_path', null,
    $modx->getOption('core_path', null, MODX_CORE_PATH) . 'components/syncmoysklad/');
if (!$syncMoySklad = $modx->getService('syncmoysklad', 'syncMoySklad', $corePath . 'model/syncmoysklad/',
    array('core_path' => $corePath))
) {
    return;
}

$className = 'syncMoySklad' . $modx->event->name;
$modx->loadClass('syncMoySkladPlugin', $syncMoySklad->getOption('modelPath') . 'syncmoysklad/systems/', true,
    true);
$modx->loadClass($className, $syncMoySklad->getOption('modelPath') . 'syncmoysklad/systems/', true, true);
if (class_exists($className)) {
    /** @var syncPlugin $handler */
    $handler = new $className($modx, $scriptProperties);
    $handler->run();
}
return;