<?php

//ini_set('display_errors', 1);
//ini_set('error_reporting', -1);

require_once dirname(__FILE__) . '/base.class.php';

class modSyncMoySkladSyncProcessor extends modSyncMoySkladMsCategoryBaseProcessor
{
    /** @var Sync $Sync */
    public $Sync;
    /** @var SyncMoySkladTools $SyncTools */
    public $SyncTools;

    /** @var mixed|null $syncService */
    protected $syncService = 'moysklad';

    /**
     * @var array
     */
    protected $steps = array(
        "sync_init",
        //
        "sync_read_currency",
        "sync_read_category",
        //
        "sync_set_sync_category",
        //
        "sync_import_upd_category",
        "sync_import_cre_category",
        //
        "sync_read_product_metadata",
        "sync_read_product",
        //
        "sync_import_upd_product",
        "sync_import_cre_product",
        //
        "sync_read_modification_metadata",
        "sync_read_modification",
        //
        "sync_import_upd_modification",
        //
        "sync_read_store",
        "sync_read_stock",
        //
        "sync_import_upd_product_stock",
        "sync_import_upd_modification_stock",
        //
        "sync_read_service_metadata",
        "sync_read_service",
        //
        "sync_import_upd_service",
        "sync_import_cre_service",
        //

        "sync_export_unl_category",
        "sync_export_upd_category",
        "sync_export_unl_new_category",
        "sync_export_cre_category",
        //
        "sync_export_unl_product",
        "sync_export_upd_product",
        "sync_export_unl_new_product",
        "sync_export_cre_product",
        //
        "sync_export_unl_modification",
        "sync_export_upd_modification",
        "sync_export_unl_new_modification",
        "sync_export_cre_modification",
        //

        "sync_export_unl_service",
        "sync_export_upd_service",
        "sync_export_unl_new_service",
        "sync_export_cre_service",

        "sync_close",
    );

    /**
     * "sync_read_currency"
     *
     * чтение валют с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadCurrency($data = array())
    {
        $syncType = "currency";
        $syncAction = "import";

        $options = array('currency');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadCurrency($row, $syncType, $syncAction)) {
                        continue;
                    }
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['code'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadCurrency();
    }

    /**
     * "sync_read_category"
     *
     * чтение категорий с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "import";

        $options = array('productFolder');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadCategory($row, $syncType, $syncAction)) {
                        continue;
                    }
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadCategory();
    }

    /**
     * "sync_read_product_metadata"
     *
     * чтение метаданных продукта с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadProductMetadata($data = array())
    {
        $syncType = "product_metadata";
        $syncAction = "import";

        $options = array('product', 'metadata');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data, 'attributes')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_attribute', $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }
            /* if ($rows = $this->getSyncRows($data, 'priceTypes')) {
                 foreach ($rows as $row) {
                     $row = array_merge($row, array(
                         'id'          => $this->modx->getOption('name', $row, ''),
                         'sync_parent' => $this->modx->getOption('name', $row, '')
                     ));
                     if ($object = $this->createSyncObject($syncType . '_price', $syncAction, $row['id'], $row)) {
                         if ($object->save()) {
                             $this->nextSyncCount();
                         }
                     }
                 }
             }*/

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadProductMetadata();
    }


    /**
     * "sync_read_service_metadata"
     *
     * чтение метаданных услуг с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadServiceMetadata($data = array())
    {
        if (!$this->getOption('process_service')) {
            return parent::stepSyncReadServiceMetadata();
        }

        $syncType = "service_metadata";
        $syncAction = "import";

        $options = array('service', 'metadata');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data, 'attributes')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_attribute', $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }
            /* if ($rows = $this->getSyncRows($data, 'priceTypes')) {
                 foreach ($rows as $row) {
                     $row = array_merge($row, array(
                         'id'          => $this->modx->getOption('name', $row, ''),
                         'sync_parent' => $this->modx->getOption('name', $row, '')
                     ));
                     if ($object = $this->createSyncObject($syncType . '_price', $syncAction, $row['id'], $row)) {
                         if ($object->save()) {
                             $this->nextSyncCount();
                         }
                     }
                 }
             }*/

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadServiceMetadata();
    }

    /**
     * "sync_read_service"
     *
     * чтение услуг с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadService($data = array())
    {
        if (!$this->getOption('process_service')) {
            return parent::stepSyncReadService();
        }

        $syncType = "service";
        $syncAction = "import";

        $options = array('service');
        $filters = $this->getSyncFilters(array(
            'expand' => 'productFolder,salePrices,group,attributes,image,supplier,country'
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadProduct($row, $syncType, $syncAction)) {
                        continue;
                    }

                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadService();
    }


    /**
     * "sync_read_product"
     *
     * чтение продуктов с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "import";

        $options = array('product');
        $filters = $this->getSyncFilters(array(
            'expand' => 'productFolder,salePrices,group,attributes,image,supplier,country'
        ));


        $addFilter = array();
        /* get not upload */
        $key = $this->getOption('filter_product_not_upload', null); // 'Не выгружать'
        if ($tmp = $this->prepareExportAttrValue(null, null, $key)) {
            $addFilter[] = "https://online.moysklad.ru/api/remap/1.1/entity/product/metadata/attributes/{$tmp['id']}=false";
        }

        /* get upload */
        $key = $this->getOption('filter_product_upload', null); // 'Выгружать'
        if ($tmp = $this->prepareExportAttrValue(null, null, $key)) {
            $addFilter[] = "https://online.moysklad.ru/api/remap/1.1/entity/product/metadata/attributes/{$tmp['id']}=true";
        }

        if (!empty($addFilter)) {
            $filters['filter'] = $this->Sync->cleanAndImplode($addFilter, ';');
        }

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadProduct($row, $syncType, $syncAction)) {
                        continue;
                    }
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadProduct();
    }

    /**
     * "sync_read_modification_metadata"
     *
     * чтение метаданных модификаций с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadModificationMetadata($data = array())
    {
        if (!$this->getOption('process_modification')) {
            return parent::stepSyncReadModificationMetadata();
        }

        $syncType = "modification_metadata";
        $syncAction = "import";

        $options = array('variant', 'metadata');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data, 'attributes')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_attribute', $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }
            if ($rows = $this->getSyncRows($data, 'characteristics')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_characteristic', $syncAction, $row['id'],
                        $row)
                    ) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadModificationMetadata();
    }

    /**
     * "sync_read_modification"
     *
     * чтение модификаций с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_import')) {
            return parent::stepSyncImportUpdModification();
        }

        $syncType = "modification";
        $syncAction = "import";

        $options = array('variant');
        $filters = $this->getSyncFilters(array(
            'expand' => 'salePrices,characteristics'//product
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadModification($row, $syncType, $syncAction)) {
                        continue;
                    }

                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadModification();
    }

    /**
     * "sync_read_store"
     *
     * чтение складов с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadStore($data = array())
    {
        if (!$this->getOption('process_stock')) {
            return parent::stepSyncReadStore();
        }

        if (!$this->getOption('product_process_stock') AND !$this->getOption('modification_process_stock')) {
            return parent::stepSyncReadStore();
        }

        $syncType = "store";
        $syncAction = "import";

        $options = array('store');
        $filters = $this->getSyncFilters(array());

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {

                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadStore();
    }

    /**
     * "sync_read_stock"
     *
     * чтение остатков с сервиса "МОЙ СКЛАД"
     */
    public function stepSyncReadStock($data = array())
    {
        if (!$this->getOption('process_stock')) {
            return parent::stepSyncReadStock();
        }

        if (!$this->getOption('product_process_stock') AND !$this->getOption('modification_process_stock')) {
            return parent::stepSyncReadStock();
        }

        $syncType = "stock";
        $syncAction = "import";

        $options = array('stock', 'all');
        $filters = $this->getSyncFilters(array(
            'groupBy' => 'variant',//'product',
            //'stockMode' => $this->getOption('filter_stock_mode', null, 'positiveOnly', true)
        ));

        /* add stock mode */
        $stockMode = $this->getOption('filter_stock_mode', null);
        if (!empty($stockMode)) {
            $filters['stockMode'] = $stockMode;
        }

        $addFilter = array();

        /* add store id */
        $stockStore = $this->getOption('filter_stock_store', null);
        $stockStore = $this->explodeAndClean($stockStore);
        foreach ($stockStore as $name) {
            $classSync = "syncObject";
            $q = $this->modx->newQuery("syncObject");
            $q->where(array(
                "{$classSync}.sync_type"    => "store",
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_parent"  => $name,
            ));
            $q->limit(1);

            $q->select('sync_id');
            if ($stmt = $q->prepare() AND $syncId = $this->modx->getValue($stmt)) {
                $addFilter[] = "store.id={$syncId}";
            }
        }
        $filters = array_merge($filters, $addFilter);

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadStock($row, $syncType, $syncAction)) {
                        continue;
                    }

                    $type = $this->modx->getOption('sync_type', $row, $syncType, true);
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($type, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadStock();
    }


    /**
     * "sync_set_sync_category"
     *
     * задаемм корневую категорию синхронизации с сервисом "МОЙ СКЛАД"
     */
    public function stepSyncSetSyncCategory($data = array())
    {
        $this->setSyncFolder();

        return $this->nextStep('', '', $data);
    }


    /**
     * "sync_import_upd_category"
     *
     * обновление категорий
     */
    public function stepSyncImportUpdCategory($data = array())
    {
        if (!$this->getOption('category_process_on_import_upd')) {
            return parent::stepSyncImportUpdCategory();
        }

        $syncType = "category";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        /* get skip fields */
        $skipFields = $this->getOption('category_skip_fields_on_upd', null, '', true);
        $skipFields = $this->Sync->explodeAndClean($skipFields);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdCategory($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, $skipFields, true);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncImportUpdCategory();
    }

    /**
     * "sync_import_cre_category"
     *
     * создание категорий
     */
    public function stepSyncImportCreCategory($data = array())
    {
        if (!$this->getOption('category_process_on_import_cre')) {
            return parent::stepSyncImportCreCategory();
        }

        $syncType = "category";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->leftJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->where(array(
            "{$classSync}.sync_type"        => $syncType,
            "{$classSync}.sync_action"      => $syncAction,
            "{$classSync}.sync_service"     => $this->syncService,
            "{$classSync}.sync_processed"   => 0,
            "{$classResource}.sync_service" => null,
        ));
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportCreCategory($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncImportCreCategory();
    }


    /**
     * "sync_import_upd_product"
     *
     * обновление продуктов
     */
    public function stepSyncImportUpdProduct($data = array())
    {
        if (!$this->getOption('product_process_on_import_upd')) {
            return parent::stepSyncImportUpdProduct();
        }

        $syncType = "product";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        $skipFields = $this->getOption('product_skip_fields_on_upd', null, '', true);
        $skipFields = $this->Sync->explodeAndClean($skipFields);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdProduct($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, $skipFields, true);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportUpdProduct();
    }

    /**
     * "sync_import_cre_product"
     *
     * создание продуктов
     */
    public function stepSyncImportCreProduct($data = array())
    {
        if (!$this->getOption('product_process_on_import_cre')) {
            return parent::stepSyncImportCreProduct();
        }

        $syncType = "product";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->leftJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->where(array(
            "{$classSync}.sync_type"        => $syncType,
            "{$classSync}.sync_action"      => $syncAction,
            "{$classSync}.sync_service"     => $this->syncService,
            "{$classSync}.sync_processed"   => 0,
            "{$classResource}.sync_service" => null,
        ));
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportCreProduct($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportCreProduct();
    }


    /**
     * "sync_import_upd_service"
     *
     * обновление услуг
     */
    public function stepSyncImportUpdService($data = array())
    {
        if (!$this->getOption('service_process_on_import_upd')) {
            return parent::stepSyncImportUpdService();
        }

        $syncType = "service";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        $skipFields = $this->getOption('service_skip_fields_on_upd', null, '', true);
        $skipFields = $this->Sync->explodeAndClean($skipFields);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdService($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, $skipFields, true);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportUpdService();
    }

    /**
     * "sync_import_cre_service"
     *
     * создание услуг
     */
    public function stepSyncImportCreService($data = array())
    {
        if (!$this->getOption('service_process_on_import_cre')) {
            return parent::stepSyncImportCreService();
        }

        $syncType = "service";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->leftJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->where(array(
            "{$classSync}.sync_type"        => $syncType,
            "{$classSync}.sync_action"      => $syncAction,
            "{$classSync}.sync_service"     => $this->syncService,
            "{$classSync}.sync_processed"   => 0,
            "{$classResource}.sync_service" => null,
        ));
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportCreService($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportCreService();
    }


    /**
     * "sync_import_upd_modification"
     *
     * обновление/создание модификаций продуктов
     */
    public function stepSyncImportUpdModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_import')) {
            return parent::stepSyncImportUpdModification();
        }

        $syncType = "modification";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->leftJoin($classResource, $classResource,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        $tmp[] = (int)$this->getOption('service_template', null);
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->select("{$classSync}.sync_parent");

        $where = $q->query['where'];

        $this->idx = $this->err = 0;
        while ($syncId = $this->modx->getValue($q->prepare())) {

            /* modify query */
            $q->select("{$classSync}.*");
            $q->query['where'] = $where;
            $q->where(array("{$classSync}.sync_parent" => $syncId));
            /* modify query */

            $modifications = array();
            $syncObjects = $this->modx->getIterator($classSync, $q);
            /** @var syncObject $syncObject */
            foreach ($syncObjects as $syncObject) {
                $syncObject->set("sync_processed", true);
                $syncObject->save();

                if (!$tmp = $this->processSyncImportModification($syncObject->toArray(), $syncType, $syncAction)) {
                    continue;
                }
                $modifications[] = $tmp;
            }

            $row = array(
                'sync_id'            => $syncId,
                'sync_modifications' => $modifications
            );

            $response = $this->processSyncResource($row, $syncType, $syncAction, array('sync_modifications'));
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                /** @var syncObject $syncObject */
                foreach ($syncObjects as $syncObject) {
                    $this->processSyncObjectError($syncObject, $data, $row);
                }
            } else {

            }

            /*if ($object = $response->getObject()) {
                print_r($object);
            }*/

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

            /* modify query */
            $q->query['where'] = $where;
            /* modify query */
        }

        return parent::stepSyncImportUpdModification();
    }


    /**
     * "sync_import_upd_product_stock"
     *
     * обновление остатков продуктов
     */
    public function stepSyncImportUpdProductStock($data = array())
    {
        if (!$this->getOption('process_stock') OR !$this->getOption('product_process_stock')) {
            return parent::stepSyncImportUpdProductStock();
        }

        $syncType = "product_stock";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}' " .
            "AND {$classSync}.sync_type = '{$syncType}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_path:LIKE" => "{$path}%",
            ));
        }

        $q->select(array(
            "{$classSync}.*",
            "{$classResource}.id as sync_resource",
        ));
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdProductStock($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $fields = $this->getOption('product_stock', null, array(), true);
            $fields = json_decode($fields, true);
            $allowedFields = array_keys($fields);

            $response = $this->processSyncResource($row, $syncType, $syncAction, $allowedFields);
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncImportUpdProductStock();
    }


    /**
     * "sync_import_upd_modification_stock"
     *
     * обновление остатков модификаций
     */
    public function stepSyncImportUpdModificationStock($data = array())
    {
        if (!$this->getOption('process_stock') OR !$this->getOption('modification_process_stock')) {
            return parent::stepSyncImportUpdModificationStock();
        }

        $syncType = "variant_stock";
        $syncAction = "import";
        $classSync = "syncObject";
        $classModification = "msopModification";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classModification, $classModification,
            "{$classModification}.sync_id = {$classSync}.sync_id " .
            "AND {$classModification}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}' " .
            "AND {$classSync}.sync_type = '{$syncType}'"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classModification}.active" => 1,
            "{$classModification}.type"   => 1,
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));

        $path = $this->getSyncResourceParentSyncPath();

        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_path:LIKE" => "{$path}%",
            ));
        }

        $q->select(array(
            "{$classSync}.*",
            "{$classModification}.id as sync_modification",
            "{$classModification}.rid as sync_resource",
        ));
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdModificationStock($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, array('sync_modification_stock'));
            $data = $response->getResponse();
            if ($response->isError()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncImportUpdModificationStock();
    }


    /**
     * "sync_export_unl_category"
     *
     * выгрузка существующих категорий в таблицу синхронизации
     */
    public function stepSyncExportUnlCategory($data = array())
    {
        if (!$this->getOption('category_process_on_export_upd')) {
            return parent::stepSyncExportUnlCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msCategory', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->sortby("{$classResource}.id", "ASC");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$alias}.sync_id as sync_parent",
        ));

        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlCategory($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlCategory();
    }

    /**
     * "sync_export_unl_new_category"
     *
     * выгрузка новых категорий в таблицу синхронизации
     */
    public function stepSyncExportUnlNewCategory($data = array())
    {
        if (!$this->getOption('category_process_on_export_cre')) {
            return parent::stepSyncExportUnlNewCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msCategory', true),
            "{$classResource}.sync_service" => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->sortby("{$classResource}.id", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlCategory($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $this->err++;
                $syncResource->set("sync_service", $this->syncService);
                $syncResource->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewCategory();
    }

    /**
     * "sync_export_unl_product"
     *
     * выгрузка существующих продуктов в таблицу синхронизации
     */
    public function stepSyncExportUnlProduct($data = array())
    {
        if (!$this->getOption('product_process_on_export_upd')) {
            return parent::stepSyncExportUnlProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        $tmp[] = (int)$this->getOption('service_template', null);
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->sortby("{$classResource}.id", "ASC");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$alias}.sync_id as sync_parent",
        ));
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {

            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlProduct();
    }

    /**
     * "sync_export_unl_new_product"
     *
     * выгрузка новых продуктов в таблицу синхронизации
     */
    public function stepSyncExportUnlNewProduct($data = array())
    {
        if (!$this->getOption('product_process_on_export_cre')) {
            return parent::stepSyncExportUnlNewProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        $tmp[] = (int)$this->getOption('service_template', null);
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->sortby("{$classResource}.id", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $syncResource->set("sync_service", $this->syncService);
                $syncResource->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewProduct();
    }


    /**
     * "sync_export_unl_modification"
     *
     * выгрузка существующих модификаций в таблицу синхронизации
     */
    public function stepSyncExportUnlModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_export_upd')) {
            return parent::stepSyncExportUnlModification();
        }

        $syncType = "modification";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";
        $classModification = "msopModification";

        $q = $this->modx->newQuery($classModification);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.id = {$classModification}.rid " .
            "AND {$classResource}.sync_service = {$classModification}.sync_service"
        );
        $q->leftJoin($classSync, $classSync,
            "{$classModification}.sync_id = {$classSync}.sync_id " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classModification}.active"   => 1,
            "{$classModification}.type"     => 1,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        $tmp[] = (int)$this->getOption('service_template', null);
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->limit(1);
        $q->groupby("{$classModification}.id");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$classResource}.sync_id as sync_parent",
            "{$alias}.rid as sync_resource",
        ));

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncModification */
        while ($syncModification = $this->modx->getObject($classModification, $q)) {

            if (!$row = $this->processSyncExportUnlModification($syncModification->toArray(), $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['sync_id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlModification();
    }

    /**
     * "sync_export_unl_new_modification"
     *
     * выгрузка новых модификаций в таблицу синхронизации
     */
    public function stepSyncExportUnlNewModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_export_cre')) {
            return parent::stepSyncExportUnlNewModification();
        }

        $syncType = "modification";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";
        $classModification = "msopModification";

        $q = $this->modx->newQuery($classModification);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.id = {$classModification}.rid"
        );
        $q->leftJoin($classSync, $classSync,
            "{$classModification}.id = {$classSync}.sync_id " .
            "AND {$classSync}.sync_action = '{$syncAction}' " .
            "AND {$classSync}.sync_type = '{$syncType}' " .
            "AND {$classSync}.sync_service = '{$this->syncService}'"
        );

        $q->where(array(
            "{$classResource}.published"        => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"        => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service"     => $this->syncService,
            "{$classResource}.deleted"          => 0,
            "{$classModification}.active"       => 1,
            "{$classModification}.type"         => 1,
            "{$classModification}.sync_service" => null,
            "{$classSync}.sync_resource"        => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        $tmp[] = (int)$this->getOption('service_template', null);
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $q->limit(1);
        $q->groupby("{$classModification}.id");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$classResource}.sync_id as sync_parent",
            "{$alias}.rid as sync_resource",
        ));

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncModification */
        while ($syncModification = $this->modx->getObject($classModification, $q)) {

            if (!$row = $this->processSyncExportUnlModification($syncModification->toArray(), $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $syncModification->set("sync_service", $this->syncService);
                $syncModification->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewModification();
    }

    /**
     * "sync_export_unl_service"
     *
     * выгрузка существующих услуг в таблицу синхронизации
     */
    public function stepSyncExportUnlService($data = array())
    {
        if (!$this->getOption('process_service') OR !$this->getOption('service_process_on_export_upd')) {
            return parent::stepSyncExportUnlService();
        }

        $syncType = "service";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $template = (int)$this->getOption('service_template', null);
        $q->andCondition(array(
            "{$classResource}.template:IN" => array($template)
        ));

        $q->sortby("{$classResource}.id", "ASC");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$alias}.sync_id as sync_parent",
        ));
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {

            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlService();
    }

    /**
     * "sync_export_unl_new_service"
     *
     * выгрузка новых услуг в таблицу синхронизации
     */
    public function stepSyncExportUnlNewService($data = array())
    {
        if (!$this->getOption('process_service') OR !$this->getOption('service_process_on_export_cre')) {
            return parent::stepSyncExportUnlNewService();
        }

        $syncType = "service";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $q->where(array(
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $parents = $this->getSyncResourceChilds();
        if (!empty($parents)) {
            $q->andCondition(array(
                "{$classResource}.parent:IN" => $parents
            ));
        }

        $tmp = $this->getSyncExcludeTemplates();
        if (!empty($tmp)) {
            $q->andCondition(array(
                "{$classResource}.template:NOT IN" => $tmp
            ));
        }

        $template = (int)$this->getOption('service_template', null);
        $q->andCondition(array(
            "{$classResource}.template:IN" => array($template)
        ));

        $q->sortby("{$classResource}.id", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $syncResource->set("sync_service", $this->syncService);
                $syncResource->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewService();
    }


    /**
     * "sync_export_upd_service"
     *
     * экспорт обновление услуг в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportUpdService($data = array())
    {
        if (!$this->getOption('process_service') OR !$this->getOption('service_process_on_export_upd')) {
            return parent::stepSyncExportUpdService();
        }

        $syncType = "service";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportUpdService($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->updateData('service', $syncObject->get('sync_parent'), $row);
            $data = $response->getResponseBody();

            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdService();
    }

    /**
     * "sync_export_cre_service"
     *
     * экспорт создание услуг в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportCreService($data = array())
    {
        if (!$this->getOption('process_service') OR !$this->getOption('service_process_on_export_cre')) {
            return parent::stepSyncExportCreService();
        }

        $syncType = "service";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent"    => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreService($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->createData('service', $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {
                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportCreService();
    }


    /**
     * "sync_export_upd_category"
     *
     * экспорт обновление категорий в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportUpdCategory($data = array())
    {
        if (!$this->getOption('category_process_on_export_upd')) {
            return parent::stepSyncExportUpdCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreCategory($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->updateData('productFolder', $syncObject->get('sync_parent'), $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdCategory();
    }

    /**
     * "sync_export_cre_category"
     *
     * экспорт создание категорий в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportCreCategory($data = array())
    {
        if (!$this->getOption('category_process_on_export_cre')) {
            return parent::stepSyncExportCreCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent"    => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreCategory($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->createData('productFolder', $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {
                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportCreCategory();
    }


    /**
     * "sync_export_upd_product"
     *
     * экспорт обновление продуктов в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportUpdProduct($data = array())
    {
        if (!$this->getOption('product_process_on_export_upd')) {
            return parent::stepSyncExportUpdProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportUpdProduct($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->updateData('product', $syncObject->get('sync_parent'), $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdProduct();
    }


    /**
     * "sync_export_cre_product"
     *
     * экспорт создание продуктов в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportCreProduct($data = array())
    {
        if (!$this->getOption('product_process_on_export_cre')) {
            return parent::stepSyncExportCreProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent"    => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreProduct($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->createData('product', $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {
                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->set("sync_data", $data);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportCreProduct();
    }

    /**
     * "sync_export_upd_modification"
     *
     * экспорт обновление модификаций в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportUpdModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_export_upd')) {
            return parent::stepSyncExportUpdModification();
        }

        $syncType = "modification";
        $syncAction = "export";
        $classSync = "syncObject";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportUpdModification($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->updateData('variant', $syncObject->get('sync_id'), $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {

            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdModification();
    }

    /**
     * "sync_export_cre_modification"
     *
     * экспорт создание модификаций в сервисе "МОЙ СКЛАД"
     */
    public function stepSyncExportCreModification($data = array())
    {
        if (!$this->getOption('process_modification') OR !$this->getOption('modification_process_on_export_cre')) {
            return parent::stepSyncExportCreModification();
        }

        $syncType = "modification";
        $syncAction = "export";
        $classSync = "syncObject";
        $classModification = "msopModification";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));

        $q->sortby("{$classSync}.sync_idx", "ASC");
        $q->limit(1);

        $this->idx = $this->err = 0;
        /** @var syncObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreModification($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->createData('variant', $row);
            $data = $response->getResponseBody();
            if (!$response->isSuccessful()) {
                $this->err++;
                $this->processSyncObjectError($syncObject, $data, $row);
            } else {
                if ($r = $this->modx->getObject($classModification,
                    array('id' => (int)$syncObject->get('sync_id')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->save();
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdModification();
    }


}

return 'modSyncMoySkladSyncProcessor';