<?php

require_once dirname(__FILE__) . '/sync.class.php';

class modSyncMoySkladStockProcessor extends modSyncMoySkladSyncProcessor
{
    /**
     * @var array
     */

    protected $steps = array(
        "sync_init",
        //
        "sync_read_currency",
        //
        "sync_read_product_metadata",
        //
        "sync_read_modification_metadata",
        //
        "sync_read_store",
        "sync_read_stock",
        //
        "sync_import_upd_product_stock",
        "sync_import_upd_modification_stock",
        //
        "sync_close",
    );

    public function initialize()
    {
        $initialize = parent::initialize();

        $this->setOption('process_stock', true);

        return $initialize;
    }

}

return 'modSyncMoySkladStockProcessor';