<?php

require_once dirname(dirname(__FILE__)) . '/mscategory/sync.class.php';

class modSyncMoySkladHookProcessor extends modSyncMoySkladSyncProcessor
{

    /** @var Sync $Sync */
    public $Sync;
    /** @var SyncMoySkladTools $SyncTools */
    public $SyncTools;

    /** @var mixed|null $syncService */
    protected $syncService = 'moysklad';

    /**
     * @var array
     */
    protected $steps = array(
        "sync_get_web_hook",
        "sync_set_web_hook",
        "sync_upd_web_hook",
        "sync_del_web_hook",
    );

    /* чтение хука с сервиса */
    public function stepSyncGetWebHook()
    {
        $options = array('webhook');
        $filters = array('limit' => 100);

        $data = array();
        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $body = $response->getResponseBody();
            $data = $this->getSyncRows($body);
        }

        return $this->success('', $data, false, $this->getStep());
    }

    /* запись хука на сервис
        [CREATE, UPDATE, DELETE]
    */
    public function stepSyncSetWebHook()
    {
        $options = 'webhook';

        $row = array_merge(array(
            "url"        => $this->SyncTools->getHookUrl(),
            "action"     => null,
            "entityType" => null
        ), (array)$this->getProperty('row'));

        $data = array();
        $response = $this->SyncTools->createData($options, $row);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
        }

        return $this->success('', $data, false, $this->getStep());
    }

    /* обновление хука на сервисе */
    public function stepSyncUpdWebHook($data = array())
    {
        $options = 'webhook';

        $row = (array)$this->getProperty('row');
        $id = isset($row['id']) ? $row['id'] : null;

        $data = array();
        $response = $this->SyncTools->updateData($options, $id, $row);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
        }

        return $this->success('', $data, false, $this->getStep());
    }

    /* удаление хука с сервиса */
    public function stepSyncDelWebHook($data = array())
    {
        $options = 'webhook';

        $row = array_merge((array)$this->getProperty('row'),
            array("enabled" => false)
        );

        $id = isset($row['id']) ? $row['id'] : null;

        $data = array();
        $response = $this->SyncTools->updateData($options, $id, $row);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
        }

        return $this->success('', $data, false, $this->getStep());
    }

}

return 'modSyncMoySkladHookProcessor';