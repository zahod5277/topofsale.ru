<?php

$_lang['area_sync_moysklad'] = 'Основные';
$_lang['area_sync_moysklad_product'] = 'Продукт';
$_lang['area_sync_moysklad_category'] = 'Категория';
$_lang['area_sync_moysklad_modification'] = 'Модификация';
$_lang['area_sync_moysklad_image'] = 'Изображение';
$_lang['area_sync_moysklad_service'] = 'Услуги';
$_lang['area_sync_moysklad_filter'] = 'Фильтр';


// main
$_lang['setting_sync_moysklad_api_endpoint'] = 'Url МойСклад Api';
$_lang['setting_sync_moysklad_api_endpoint_desc'] = 'Url для отправки запроса к МойСклад Api';

$_lang['setting_sync_moysklad_api_user'] = 'Логин пользователя МойСклад';
$_lang['setting_sync_moysklad_api_user_desc'] = 'Логин пользователя МойСклад';

$_lang['setting_sync_moysklad_api_password'] = 'Пароль пользователя МойСклад';
$_lang['setting_sync_moysklad_api_password_desc'] = 'Пароль пользователя МойСклад';

$_lang['setting_sync_moysklad_api_limit'] = 'Лимит обработки данных';
$_lang['setting_sync_moysklad_api_limit_desc'] = 'Лимит обработки данных';

$_lang['setting_sync_moysklad_actions'] = 'Доступные действия';
$_lang['setting_sync_moysklad_actions_desc'] = 'Доступные действия';

$_lang['setting_sync_moysklad_sync_archived'] = 'Синхронизировать архивные данные';
$_lang['setting_sync_moysklad_sync_archived_desc'] = 'Синхронизировать архивные данные';

$_lang['setting_sync_moysklad_sync_folder'] = 'Папка синхронизации';
$_lang['setting_sync_moysklad_sync_folder_desc'] = 'Название папки МойСклад';

$_lang['setting_sync_moysklad_sync_parent'] = 'Категория синхронизации';
$_lang['setting_sync_moysklad_sync_parent_desc'] = 'Категория сайта';

$_lang['setting_sync_moysklad_sync_lock'] = 'Блокировать синхронизацию';
$_lang['setting_sync_moysklad_sync_lock_desc'] = 'Блокировать одновременный запуск нескольких процессов синхронизации ';

$_lang['setting_sync_moysklad_sync_lock'] = 'Блокировать синхронизацию';
$_lang['setting_sync_moysklad_sync_lock_desc'] = 'Блокировать одновременный запуск нескольких процессов синхронизации ';

$_lang['setting_sync_moysklad_web_hook_url'] = 'Url webhook';
$_lang['setting_sync_moysklad_web_hook_url_desc'] = 'Url для получения ответов от МойСклад Api';

$_lang['setting_sync_moysklad_currency'] = 'Валюта магазина';
$_lang['setting_sync_moysklad_currency_desc'] = 'Код валюты магазина';

$_lang['setting_sync_moysklad_currency_rate'] = 'Ставка магазина';
$_lang['setting_sync_moysklad_currency_rated_desc'] = 'Тарифная ставка магазина';

$_lang['setting_sync_moysklad_process_tmp'] = 'Обрабатывать временные файлы';
$_lang['setting_sync_moysklad_process_tmp_desc'] = 'Обрабатывать временные файлы. Очищать после завершения синхронизации';

$_lang['setting_sync_moysklad_process_price'] = 'Обрабатывать цены';
$_lang['setting_sync_moysklad_process_price_desc'] = 'Обрабатывать цены при синхронизации';

$_lang['setting_sync_moysklad_process_image'] = 'Обрабатывать изображения';
$_lang['setting_sync_moysklad_process_image_desc'] = 'Обрабатывать изображения при синхронизации';

$_lang['setting_sync_moysklad_process_modification'] = 'Обрабатывать модификации';
$_lang['setting_sync_moysklad_process_modification_desc'] = 'Обрабатывать модификации при синхронизации';

$_lang['setting_sync_moysklad_process_stock'] = 'Обрабатывать остатки';
$_lang['setting_sync_moysklad_process_stock_desc'] = 'Обрабатывать остатки при синхронизации';

$_lang['setting_sync_moysklad_process_service'] = 'Обрабатывать услуги';
$_lang['setting_sync_moysklad_process_service_desc'] = 'Обрабатывать услуги при синхронизации';

$_lang['setting_sync_moysklad_compatibility_1c'] = 'Совместимость 1С';
$_lang['setting_sync_moysklad_compatibility_1c_desc'] = 'Обрабатывать свойств при синхронизации для улучшения совместимости с 1С';



// category
$_lang['setting_sync_moysklad_category_class_key'] = 'Класс категории';
$_lang['setting_sync_moysklad_category_class_key_desc'] = 'Класс категории';

$_lang['setting_sync_moysklad_category_template'] = 'Шаблон категории';
$_lang['setting_sync_moysklad_category_template_desc'] = 'Шаблон категории';

$_lang['setting_sync_moysklad_category_published'] = 'Статус категории';
$_lang['setting_sync_moysklad_category_published_desc'] = 'Статус публикации категории';

$_lang['setting_sync_moysklad_category_fields'] = 'Поля категории';
$_lang['setting_sync_moysklad_category_fields_desc'] = 'Основные поля категории продукта, массив соответсвия полей';

$_lang['setting_sync_moysklad_category_skip_fields_on_upd'] = 'Пропускать поля категории';
$_lang['setting_sync_moysklad_category_skip_fields_on_upd_desc'] = 'Пропускать следующие поля ресурса при обновлении категории';

$_lang['setting_sync_moysklad_category_process_on_import_upd'] = 'Обновлять категории импорта';
$_lang['setting_sync_moysklad_category_process_on_import_upd_desc'] = 'Обновлять существующие категории при импорте';

$_lang['setting_sync_moysklad_category_process_on_import_cre'] = 'Создавать категории импорта';
$_lang['setting_sync_moysklad_category_process_on_import_cre_desc'] = 'Создавать новые категории при импорте';

$_lang['setting_sync_moysklad_category_process_on_export_upd'] = 'Обновлять категории экспорта';
$_lang['setting_sync_moysklad_category_process_on_export_upd_desc'] = 'Обновлять существующие категории при экспорте';

$_lang['setting_sync_moysklad_category_process_on_export_cre'] = 'Создавать категории экспорта';
$_lang['setting_sync_moysklad_category_process_on_export_cre_desc'] = 'Создавать новые категории при экспорте';


// product
$_lang['setting_sync_moysklad_product_class_key'] = 'Класс продукта';
$_lang['setting_sync_moysklad_product_class_key_desc'] = 'Класс продукта';

$_lang['setting_sync_moysklad_product_template'] = 'Шаблон продукта';
$_lang['setting_sync_moysklad_product_template_desc'] = 'Шаблон продукта';

$_lang['setting_sync_moysklad_product_published'] = 'Статус продукта';
$_lang['setting_sync_moysklad_product_published_desc'] = 'Статус публикации продукта';

$_lang['setting_sync_moysklad_product_fields'] = 'Поля продукта';
$_lang['setting_sync_moysklad_product_fields_desc'] = 'Основные поля продукта, массив соответсвия полей';

$_lang['setting_sync_moysklad_product_skip_fields_on_upd'] = 'Пропускать поля продукта';
$_lang['setting_sync_moysklad_product_skip_fields_on_upd_desc'] = 'Пропускать следующие поля ресурса при обновлении продукта';

$_lang['setting_sync_moysklad_product_stock'] = 'Остатки продукта';
$_lang['setting_sync_moysklad_product_stock_desc'] = 'Остатки продукта, массив соответсвия полей';

$_lang['setting_sync_moysklad_product_price'] = 'Цены продукта';
$_lang['setting_sync_moysklad_product_price_desc'] = 'Цены продукта, массив соответсвия полей';

$_lang['setting_sync_moysklad_product_attributes'] = 'Атрибуты продукта';
$_lang['setting_sync_moysklad_product_attributes_desc'] = 'Дополнительные атрибуты продукта, массив соответсвия полей';


$_lang['setting_sync_moysklad_product_process_on_import_upd'] = 'Обновлять продукта импорта';
$_lang['setting_sync_moysklad_product_process_on_import_upd_desc'] = 'Обновлять существующие продукты при импорте';

$_lang['setting_sync_moysklad_product_process_on_import_cre'] = 'Создавать продукта импорта';
$_lang['setting_sync_moysklad_product_process_on_import_cre_desc'] = 'Создавать новые продукты при импорте';

$_lang['setting_sync_moysklad_product_process_on_export_upd'] = 'Обновлять продукта экспорта';
$_lang['setting_sync_moysklad_product_process_on_export_upd_desc'] = 'Обновлять существующие продукты при экспорте';

$_lang['setting_sync_moysklad_product_process_on_export_cre'] = 'Создавать продукта экспорта';
$_lang['setting_sync_moysklad_product_process_on_export_cre_desc'] = 'Создавать новые продукты при экспорте';

$_lang['setting_sync_moysklad_product_process_attributes_on_import'] = 'Обрабатывать атрибуты продукта импорта';
$_lang['setting_sync_moysklad_product_process_attributes_on_import_desc'] = 'Обрабатывать атрибуты продукта при импорте';

$_lang['setting_sync_moysklad_product_process_attributes_on_export'] = 'Обрабатывать атрибуты продукта экспорта';
$_lang['setting_sync_moysklad_product_process_attributes_on_export_desc'] = 'Обрабатывать атрибуты продукта при экспорте';

$_lang['setting_sync_moysklad_product_process_image_on_import_cre'] = 'Обрабатывать изображения импорта';
$_lang['setting_sync_moysklad_product_process_image_on_import_cre_desc'] = 'Обрабатывать изображения при импорте и создании продукта';

$_lang['setting_sync_moysklad_product_process_image_on_import_upd'] = 'Обрабатывать изображения импорта';
$_lang['setting_sync_moysklad_product_process_image_on_import_upd_desc'] = 'Обрабатывать изображения при импорте и обновлении продукта';

$_lang['setting_sync_moysklad_product_process_image_on_export_cre'] = 'Обрабатывать изображения экспорта';
$_lang['setting_sync_moysklad_product_process_image_on_export_cre_desc'] = 'Обрабатывать изображения при экспорте и создании продукта';

$_lang['setting_sync_moysklad_product_process_image_on_export_upd'] = 'Обрабатывать изображения экспорта';
$_lang['setting_sync_moysklad_product_process_image_on_export_upd_desc'] = 'Обрабатывать изображения при экспорте и обновлении продукта';

$_lang['setting_sync_moysklad_product_process_price_on_import_cre'] = 'Обрабатывать цены продукта импорта';
$_lang['setting_sync_moysklad_product_process_price_on_import_cre_desc'] = 'Обрабатывать цены продукта при импорте и создании продукта';

$_lang['setting_sync_moysklad_product_process_price_on_import_upd'] = 'Обрабатывать цены продукта импорта';
$_lang['setting_sync_moysklad_product_process_price_on_import_upd_desc'] = 'Обрабатывать цены продукта при импорте и обновлении продукта';

$_lang['setting_sync_moysklad_product_process_price_on_export_cre'] = 'Обрабатывать цены продукта экспорта';
$_lang['setting_sync_moysklad_product_process_price_on_export_cre_desc'] = 'Обрабатывать цены продукта при экспорте и создании продукта';

$_lang['setting_sync_moysklad_product_process_price_on_export_upd'] = 'Обрабатывать цены продукта экспорта';
$_lang['setting_sync_moysklad_product_process_price_on_export_upd_desc'] = 'Обрабатывать цены продукта при экспорте и обновлении продукта';

$_lang['setting_sync_moysklad_product_process_stock'] = 'Обрабатывать остатки продукта';
$_lang['setting_sync_moysklad_product_process_stock_desc'] = 'Обрабатывать остатки продукта при синхронизации';



// modification
$_lang['setting_sync_moysklad_modification_fields'] = 'Поля модификации';
$_lang['setting_sync_moysklad_modification_fields_desc'] = 'Основные поля модификации, массив соответсвия полей';

$_lang['setting_sync_moysklad_modification_characteristics'] = 'Характеристики модификации';
$_lang['setting_sync_moysklad_modification_characteristics_desc'] = 'Характеристики модификации, массив соответсвия полей';

$_lang['setting_sync_moysklad_modification_price'] = 'Цены модификации';
$_lang['setting_sync_moysklad_modification_price_desc'] = 'Цены модификации, массив соответсвия полей';

$_lang['setting_sync_moysklad_modification_stock'] = 'Остатки модификации';
$_lang['setting_sync_moysklad_modification_stock_desc'] = 'Остатки модификации, массив соответсвия полей';

$_lang['setting_sync_moysklad_modification_process_on_import'] = 'Обрабатывать модификации импорта';
$_lang['setting_sync_moysklad_modification_process_on_import_desc'] = 'Обрабатывать модификации продукта при импорте';

$_lang['setting_sync_moysklad_modification_process_on_export_upd'] = 'Обрабатывать модификации экспорта';
$_lang['setting_sync_moysklad_modification_process_on_export_upd_desc'] = 'Обрабатывать модификации при экспорте и создании';

$_lang['setting_sync_moysklad_modification_process_on_export_cre'] = 'Обрабатывать модификации экспорта';
$_lang['setting_sync_moysklad_modification_process_on_export_cre_desc'] = 'Обрабатывать модификации при экспорте и обновлении';

$_lang['setting_sync_moysklad_modification_process_price_on_export'] = 'Обрабатывать цену модификации экспорта';
$_lang['setting_sync_moysklad_modification_process_price_on_export_desc'] = 'Обрабатывать цену модификации при экспорте';

$_lang['setting_sync_moysklad_modification_process_char_on_export'] = 'Обрабатывать характеристики модификации экспорта';
$_lang['setting_sync_moysklad_modification_process_char_on_export_desc'] = 'Обрабатывать характеристики модификации при экспорте';

$_lang['setting_sync_moysklad_modification_process_stock'] = 'Обрабатывать остатки модификации';
$_lang['setting_sync_moysklad_modification_process_stock_desc'] = 'Обрабатывать остатки модификации при синхронизации';


// service
$_lang['setting_sync_moysklad_service_class_key'] = 'Класс услуги';
$_lang['setting_sync_moysklad_service_class_key_desc'] = 'Класс услуги';

$_lang['setting_sync_moysklad_service_template'] = 'Шаблон услуги';
$_lang['setting_sync_moysklad_service_template_desc'] = 'Шаблон услуги';

$_lang['setting_sync_moysklad_service_published'] = 'Статус услуги';
$_lang['setting_sync_moysklad_service_published_desc'] = 'Статус публикации услуги';

$_lang['setting_sync_moysklad_service_fields'] = 'Поля услуги';
$_lang['setting_sync_moysklad_service_fields_desc'] = 'Основные поля услуги, массив соответсвия полей';

$_lang['setting_sync_moysklad_service_skip_fields_on_upd'] = 'Пропускать поля услуги';
$_lang['setting_sync_moysklad_service_skip_fields_on_upd_desc'] = 'Пропускать следующие поля ресурса при обновлении услуги';

$_lang['setting_sync_moysklad_service_price'] = 'Цены услуги';
$_lang['setting_sync_moysklad_service_price_desc'] = 'Цены услуги, массив соответсвия полей';

$_lang['setting_sync_moysklad_service_attributes'] = 'Атрибуты услуги';
$_lang['setting_sync_moysklad_service_attributes_desc'] = 'Дополнительные атрибуты услуги, массив соответсвия полей';

$_lang['setting_sync_moysklad_service_process_on_import_upd'] = 'Обновлять услуги импорта';
$_lang['setting_sync_moysklad_service_process_on_import_upd_desc'] = 'Обновлять существующие услуги при импорте';

$_lang['setting_sync_moysklad_service_process_on_import_cre'] = 'Создавать услуги импорта';
$_lang['setting_sync_moysklad_service_process_on_import_cre_desc'] = 'Создавать новые услуги при импорте';

$_lang['setting_sync_moysklad_service_process_on_export_upd'] = 'Обновлять услуги экспорта';
$_lang['setting_sync_moysklad_service_process_on_export_upd_desc'] = 'Обновлять существующие услуги при экспорте';

$_lang['setting_sync_moysklad_service_process_on_export_cre'] = 'Создавать услуги экспорта';
$_lang['setting_sync_moysklad_service_process_on_export_cre_desc'] = 'Создавать новые услуги при экспорте';

$_lang['setting_sync_moysklad_service_process_price_on_import_cre'] = 'Обрабатывать цены услуги импорта';
$_lang['setting_sync_moysklad_service_process_price_on_import_cre_desc'] = 'Обрабатывать цены услуги при импорте и создании услуги';

$_lang['setting_sync_moysklad_service_process_price_on_import_upd'] = 'Обрабатывать цены услуги импорта';
$_lang['setting_sync_moysklad_service_process_price_on_import_upd_desc'] = 'Обрабатывать цены услуги при импорте и обновлении услуги';

$_lang['setting_sync_moysklad_service_process_price_on_export_cre'] = 'Обрабатывать цены услуги экспорта';
$_lang['setting_sync_moysklad_service_process_price_on_export_cre_desc'] = 'Обрабатывать цены услуги при экспорте и создании услуги';

$_lang['setting_sync_moysklad_service_process_price_on_export_upd'] = 'Обрабатывать цены услуги экспорта';
$_lang['setting_sync_moysklad_service_process_price_on_export_upd_desc'] = 'Обрабатывать цены услуги при экспорте и обновлении услуги';

$_lang['setting_sync_moysklad_service_process_attributes_on_import'] = 'Обрабатывать атрибуты услуги импорта';
$_lang['setting_sync_moysklad_service_process_attributes_on_import_desc'] = 'Обрабатывать атрибуты услуги при импорте';

$_lang['setting_sync_moysklad_service_process_attributes_on_export'] = 'Обрабатывать атрибуты услуги экспорта';
$_lang['setting_sync_moysklad_service_process_attributes_on_export_desc'] = 'Обрабатывать атрибуты услуги при экспорте';


// filter
$_lang['setting_sync_moysklad_filter_stock_mode'] = 'Фильтр вида остатков';
$_lang['setting_sync_moysklad_filter_stock_mode_desc'] = 'Режим фильтрации вида остатоков. По умолчанию "positiveOnly".'.
    " <a target='_blank' href='https://online.moysklad.ru/api/remap/1.1/doc/index.html#отчёт-остатки-все-остатки-get'>Подробнее...</a>";

$_lang['setting_sync_moysklad_filter_product_not_upload'] = 'Фильтр продуктов';
$_lang['setting_sync_moysklad_filter_product_not_upload_desc'] = 'Фильтр невыгружаемых продуктов. Продукты будут отфильтрованы с учетом указанного атрибута.';

$_lang['setting_sync_moysklad_filter_product_upload'] = 'Фильтр продуктов';
$_lang['setting_sync_moysklad_filter_product_upload_desc'] = 'Фильтр выгружаемых продуктов. Продукты будут отфильтрованы с учетом указанного атрибута.';

$_lang['setting_sync_moysklad_filter_stock_store'] = 'Фильтр остатков магазина';
$_lang['setting_sync_moysklad_filter_stock_store_desc'] = 'Фильтр остатков магазина. Остатки будут отфильтрованы с учетом названия склада.';

