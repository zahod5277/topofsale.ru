<?php

ini_set('display_errors', 1);
ini_set('error_reporting', -1);

/** @noinspection PhpIncludeInspection */
require_once dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/sync/processors/mgr/sync/sync.class.php';

class modSyncMoySkladSyncProcessor extends modSyncSyncProcessor
{

    /** @var Sync $Sync */
    public $Sync;
    /** @var SyncMoySkladTools $SyncTools */
    public $SyncTools;

    /** @var mixed|null $syncService */
    protected $syncService = 'moysklad';

    /**
     * @var array
     */
    protected $steps = array(
        "sync_init",

        "sync_read_currency",
        "sync_read_product_metadata",
        "sync_read_category",
        "sync_read_product",
        "sync_read_modification_metadata",
        "sync_read_modification",
        "sync_read_product_stock",
        "sync_read_modification_stock",

        "sync_import",
        "sync_import_upd_category",
        "sync_import_cre_category",

        "sync_import_upd_product",
        "sync_import_cre_product",

        "sync_import_upd_modification",

        "sync_import_upd_product_stock",
        "sync_import_upd_modification_stock",//

        "sync_export",
        "sync_export_unl_category",
        "sync_export_upd_category",
        "sync_export_unl_new_category",
        "sync_export_cre_category",

        "sync_export_unl_product",
        "sync_export_upd_product",
        "sync_export_unl_new_product",
        "sync_export_cre_product",

        "sync_export_unl_modification",//
        "sync_export_upd_modification",//
        "sync_export_unl_new_modification",//
        "sync_export_cre_modification",//

        "sync_close",
    );


    public function setSyncService($service = 'moysklad')
    {
        $this->syncService = $service;

        return $this->Sync->loadSyncTools($this->syncService);
    }

    public function getSyncResourceParentSyncData($rid = 0, $includeCurr = true)
    {
        $data = array();
        $parents = $this->getSyncResourceParents($rid, $includeCurr);

        foreach ($parents as $parent) {
            /** @var modResource $syncResource */
            if ($syncResource = $this->modx->getObject('modResource', (int)$parent)) {
                $syncService = $syncResource->get('sync_service');
                if ($syncService == $this->syncService) {
                    if ($data = $syncResource->get('sync_data')) {
                        return $data;
                    }
                }
            }
        }

        return $data;
    }

    public function getSyncResourceParentSyncPath($rid = 0, $includeCurr = true)
    {
        $data = $this->getSyncResourceParentSyncData($rid, $includeCurr);
        $syncPath = $this->modx->getOption('sync_path', $data);

        return $syncPath;
    }

    public function getSyncResourceParentSyncMeta($rid = 0, $includeCurr = true)
    {
        $data = $this->getSyncResourceParentSyncData($rid, $includeCurr);
        $syncMeta = $this->modx->getOption('meta', $data);

        /* поиск среди категорий моего склада */
        if (empty($syncMeta)) {
            $syncAction = "import";
            $classSync = "syncObject";
            $syncFolder = $this->getOption('sync_folder', null);

            $q = $this->modx->newQuery($classSync);
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncFolder,
            ));

            if ($syncObject = $this->modx->getObject($classSync, $q)) {
                $syncData = $syncObject->get('sync_data');
                $syncMeta = $this->modx->getOption('meta', $syncData);
            };
        }

        return $syncMeta;
    }

    public function getSyncResourceImportFolder($name = '', $syncParent = '')
    {
        $importFolder = $this->explodeAndClean($this->getOption('sync_folder', null));
        if (!empty($importFolder)) {
            $pathName = $this->explodeAndClean($syncParent, '/');
            $basePathName = reset($pathName);
            if (
                !in_array($name, $importFolder)
                AND
                !in_array($basePathName, $importFolder)
            ) {
                return null;
            }
        }

        return !empty($importFolder) ? $importFolder : null;
    }

    public function getSyncObjectUuid(array $data = array())
    {
        return $this->SyncTools->getUuidByMeta($this->modx->getOption('meta', $data));
    }

    /* чтение валют с сервиса */
    public function stepSyncReadCurrency($data = array())
    {
        $syncType = "currency";
        $syncAction = "import";

        $options = array('currency');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['code'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadCurrency();
    }

    /* чтение мета продукта с сервиса */
    public function stepSyncReadProductMetadata($data = array())
    {
        $syncType = "product_metadata";
        $syncAction = "import";

        $options = array('product', 'metadata');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data, 'attributes')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_attribute', $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }
            /* if ($rows = $this->getSyncRows($data, 'priceTypes')) {
                 foreach ($rows as $row) {
                     $row = array_merge($row, array(
                         'id'          => $this->modx->getOption('name', $row, ''),
                         'sync_parent' => $this->modx->getOption('name', $row, '')
                     ));
                     if ($object = $this->createSyncObject($syncType . '_price', $syncAction, $row['id'], $row)) {
                         if ($object->save()) {
                             $this->nextSyncCount();
                         }
                     }
                 }
             }*/

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadProductMetadata();
    }

    /* чтение категорий с сервиса */
    public function stepSyncReadCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "import";

        $options = array('productFolder');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadCategory($row, $syncType, $syncAction)) {
                        continue;
                    }
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadCategory();
    }

    /* чтение продуктов с сервиса */
    public function stepSyncReadProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "import";

        $options = array('product');
        $filters = $this->getSyncFilters(array(
            'expand' => 'productFolder,salePrices,group,attributes,image,supplier,country'
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();

            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadProduct($row, $syncType, $syncAction)) {
                        continue;
                    }
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                //return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadProduct();
    }

    /* чтение мета модификаций с сервиса */
    public function stepSyncReadModificationMetadata($data = array())
    {
        if (!$this->getOption('process_modification')) {
            return parent::stepSyncReadModificationMetadata();
        }

        $syncType = "modification_metadata";
        $syncAction = "import";

        $options = array('variant', 'metadata');
        $filters = $this->getSyncFilters();

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data, 'attributes')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_attribute', $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }
            if ($rows = $this->getSyncRows($data, 'characteristics')) {
                foreach ($rows as $row) {
                    $row = array_merge($row, array(
                        'sync_parent' => $this->modx->getOption('name', $row, '')
                    ));
                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType . '_characteristic', $syncAction, $row['id'],
                        $row)
                    ) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadModificationMetadata();
    }

    /* чтение модификаций с сервиса */
    public function stepSyncReadModification($data = array())
    {
        if (!$this->getOption('process_modification')) {
            return parent::stepSyncReadModification();
        }

        $syncType = "modification";
        $syncAction = "import";

        $options = array('variant');
        $filters = $this->getSyncFilters(array(
            'expand' => 'salePrices,characteristics'//product
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadModification($row, $syncType, $syncAction)) {
                        continue;
                    }

                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadModification();
    }

    public function stepSyncReadProductStock($data = array())
    {
        if (!$this->getOption('process_stock') OR !$this->getOption('product_process_stock')) {
            return parent::stepSyncReadProductStock();
        }

        $syncType = "product_stock";
        $syncAction = "import";

        $options = array('stock', 'all');
        $filters = $this->getSyncFilters(array(
            'groupBy'   => 'product',
            'stockMode' => 'all',
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {
                    if (!$row = $this->processSyncReadProductStock($row, $syncType, $syncAction)) {
                        continue;
                    }

                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadProductStock();
    }

    public function stepSyncReadModificationStock($data = array())
    {
        if (!$this->getOption('process_stock') OR !$this->getOption('modification_process_stock')) {
            return parent::stepSyncReadModificationStock();
        }

        $syncType = "modification_stock";
        $syncAction = "import";

        $options = array('stock', 'all');
        $filters = $this->getSyncFilters(array(
            'groupBy'   => 'variant',
            'stockMode' => 'all',
        ));

        $response = $this->SyncTools->getData($options, $filters);
        if ($response->isSuccessful()) {
            $data = $response->getResponseBody();
            if ($rows = $this->getSyncRows($data)) {
                foreach ($rows as $row) {

                    /////////////////////// TODO
                    print_r($row);
                    die;
                    if (!$row = $this->processSyncReadProductStock($row, $syncType, $syncAction)) {
                        continue;
                    }

                    /** @var xPDOObject $object */
                    if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                        if ($object->save()) {
                            $this->nextSyncCount();
                        }
                    }
                }
            }

            $this->processExpense();

            if ($filters = $this->processSyncFilters($data)) {
                return $this->currentStep(array('sync_filters' => $filters));
            }
        }

        return parent::stepSyncReadModificationStock();
    }


    public function stepSyncImport($data = array())
    {
        /* задаемм корневую категорию */
        $syncFolder = $this->getOption('sync_folder', null);
        $syncParent = $this->getOption('sync_parent', null);
        if (empty($syncFolder) OR empty($syncParent)) {
            $this->log("[" . __CLASS__ . "] Empty sync folder", $syncFolder, true);
            $this->log("[" . __CLASS__ . "] Empty sync parent", $syncParent, true);
        } else {

            $syncAction = "import";
            $classSync = "syncObject";
            $classResource = "modResource";

            $q = $this->modx->newQuery($classSync);
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncFolder,
            ));

            $syncObject = $this->modx->getObject($classSync, $q);
            $syncResource = $this->modx->getObject($classResource, (int)$syncParent);

            if ($syncObject AND $syncResource) {
                $syncResource->set('sync_id', $syncObject->get('sync_id'));
                $syncResource->set('sync_service', $this->syncService);
                $syncResource->save();
            } else {
                $this->log("[" . __CLASS__ . "] Error set sync parent", '', true);
            }
        }

        return parent::stepSyncImport();
    }

    /* обновление категорий */
    public function stepSyncImportUpdCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";


        /*$path = $this->getSyncResourceParentSyncPath();
       if (!empty($path)) {
           $filter['pathName'][] = $path;
       }
       foreach ($filter as $k => $v) {
           $filters['filter'] .= $k . '=' . $this->Sync->cleanAndImplode($v, ';');
       }*/


        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->limit(1);

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $skipFields = $this->getOption('category_skip_fields_on_upd', null, '', true);
        $skipFields = $this->Sync->explodeAndClean($skipFields);

        //$idx = 0;

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdCategory($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, $skipFields, true);
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportUpdCategory();
    }

    /* создание категорий */
    public function stepSyncImportCreCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->limit(1);
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {

            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportCreCategory($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction);
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }


            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->set("sync_service", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportCreCategory();
    }

    /* обновление продуктов */
    public function stepSyncImportUpdProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->limit(1);

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $skipFields = $this->getOption('product_skip_fields_on_upd', null, '', true);
        $skipFields = $this->Sync->explodeAndClean($skipFields);

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdProduct($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction, $skipFields, true);
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportUpdProduct();
    }

    /* создание продуктов */
    public function stepSyncImportCreProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->limit(1);

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_parent:LIKE" => "{$path}%",
            ));
        }

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportCreProduct($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $response = $this->processSyncResource($row, $syncType, $syncAction);
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

        }

        return parent::stepSyncImportCreProduct();
    }


    /* обновление/создание модификаций продуктов */
    public function stepSyncImportUpdModification($data = array())
    {
        if (!$this->getOption('process_modification')) {
            return parent::stepSyncImportUpdModification();
        }

        $syncType = "modification";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->leftJoin($classResource, $classResource,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $parents = $this->getSyncResourceChilds();
        $q->where(array(
            "{$classResource}.parent:IN"  => $parents,
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->select("{$classSync}.sync_parent");

        $where = $q->query['where'];

        $this->idx = $this->err = 0;
        while ($syncId = $this->modx->getValue($q->prepare())) {

            /* modify query */
            $q->select("{$classSync}.*");
            $q->query['where'] = $where;
            $q->where(array("{$classSync}.sync_parent" => $syncId));
            /* modify query */

            $modifications = array();
            $syncObjects = $this->modx->getIterator($classSync, $q);
            /** @var xPDOObject $syncObject */
            foreach ($syncObjects as $syncObject) {
                $syncObject->set("sync_processed", true);
                $syncObject->save();

                if (!$tmp = $this->processSyncImportModification($syncObject->toArray(), $syncType, $syncAction)) {
                    continue;
                }
                $modifications[] = $tmp;
            }

            $row = array(
                'sync_id'            => $syncId,
                'sync_modifications' => $modifications
            );

            $response = $this->processSyncResource($row, $syncType, $syncAction, array('sync_modifications'));
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }

            /*if ($object = $response->getObject()) {
                print_r($object);
            }*/

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }

            /* modify query */
            $q->query['where'] = $where;
            /* modify query */
        }

        return parent::stepSyncImportUpdModification();
    }

    /* обновление остатков продуктов */
    public function stepSyncImportUpdProductStock($data = array())
    {
        if (!$this->getOption('process_stock') OR !$this->getOption('product_process_stock')) {
            return parent::stepSyncImportUpdProductStock();
        }

        $syncType = "product_stock";
        $syncAction = "import";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.sync_id = {$classSync}.sync_id " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
        ));
        $q->limit(1);

        $path = $this->getSyncResourceParentSyncPath();
        if (!empty($path)) {
            $q->andCondition(array(
                "{$classSync}.sync_path:LIKE" => "{$path}%",
            ));
        }

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncImportUpdProductStock($syncObject->toArray(), $syncType, $syncAction)) {
                continue;
            }

            $fields = $this->getOption('product_stock', null, array(), true);
            $fields = json_decode($fields, true);
            $allowedFields = array_keys($fields);

            $response = $this->processSyncResource($row, $syncType, $syncAction, $allowedFields);
            if ($response->isError()) {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($response->getResponse(), true));
                $syncObject->save();

                return $response->getResponse();
            }

            if ($object = $response->getObject()) {
                $syncObject->set("sync_resource", $object['id']);
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncImportUpdProductStock();
    }


    /* очистка таблиц категорий */
    public function stepSyncExport($data = array())
    {
        //$this->clearSyncTable();

        return parent::stepSyncExport();
    }

    /* подготовка существующих категорий для обновления экспорта */
    public function stepSyncExportUnlCategory($data = array())
    {
        if (!$this->getOption('process_category_on_export_upd')) {
            return parent::stepSyncExportUnlCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );

        $parents = $this->getSyncResourceChilds();

        $q->where(array(
            "{$classResource}.parent:IN"    => $parents,
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msCategory', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));
        $q->limit(1);
        $q->sortby("{$classResource}.id", "ASC");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$alias}.sync_id as sync_parent",
        ));

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlCategory($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlCategory();
    }

    /* подготовка новых категорий для экспорта */
    public function stepSyncExportUnlNewCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource "
        );

        $parents = $this->getSyncResourceChilds();
        $q->where(array(
            "{$classResource}.parent:IN"    => $parents,
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msCategory', true),
            "{$classResource}.sync_service" => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));

        $q->limit(1);
        $q->sortby("{$classResource}.id", "ASC");

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlCategory($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $this->err++;
                $syncResource->set("sync_service", $this->syncService);
                $syncResource->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewCategory();
    }

    /* экспорт обновление категорий в сервисе */
    public function stepSyncExportUpdCategory($data = array())
    {
        if (!$this->getOption('process_category_on_export_upd')) {
            return parent::stepSyncExportUpdCategory();
        }

        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));
        $q->limit(1);
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreCategory($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->updateData('productFolder', $syncObject->get('sync_parent'), $row);
            $data = $response->getResponseBody();
            if ($response->isSuccessful()) {

                /* TODO */

            } else {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($data, true));
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdCategory();
    }

    /* экспорта создание категорий в сервисе */
    public function stepSyncExportCreCategory($data = array())
    {
        $syncType = "category";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent"    => "",
        ));
        $q->limit(1);
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreCategory($syncObject->toArray(), $syncType,
                $syncAction = "unload")
            ) {
                continue;
            }

            $response = $this->SyncTools->createData('productFolder', $row);
            $data = $response->getResponseBody();
            if ($response->isSuccessful()) {
                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->set("sync_data", $data);
                    $r->save();
                }
            } else {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($data, true));
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportCreCategory();
    }


    /* подготовка существующих продуктов для обновления экспорта */
    public function stepSyncExportUnlProduct($data = array())
    {
        if (!$this->getOption('process_product_on_export_upd')) {
            return parent::stepSyncExportUnlProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource " .
            "AND {$classResource}.sync_service = {$classSync}.sync_service"
        );

        $parents = $this->getSyncResourceChilds();
        $q->where(array(
            "{$classResource}.parent:IN"    => $parents,
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));
        $q->limit(1);
        $q->sortby("{$classResource}.id", "ASC");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$alias}.sync_id as sync_parent",
        ));

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {

            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlProduct();
    }


    /* подготовка новых продуктов для экспорта */
    public function stepSyncExportUnlNewProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classResource);
        $q->leftJoin($classSync, $classSync,
            "{$classResource}.id = {$classSync}.sync_resource "
        );

        $parents = $this->getSyncResourceChilds();

        $q->where(array(
            "{$classResource}.parent:IN"    => $parents,
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => "",
            "{$classResource}.deleted"      => 0,
            "{$classSync}.sync_resource"    => null,
        ));
        $q->limit(1);
        $q->sortby("{$classResource}.id", "ASC");

        $this->idx = $this->err = 0;
        /** @var modResource $syncResource */
        while ($syncResource = $this->modx->getObject($classResource, $q)) {
            $row = array_merge($syncResource->toArray(), $this->Sync->getResourceTvs($syncResource));
            if (!$row = $this->processSyncExportUnlProduct($row, $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['id'], $row)) {
                if ($object->save()) {
                }
            } else {
                $syncResource->set("sync_service", $this->syncService);
                $syncResource->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlNewProduct();
    }

    /* экспорт обновление продуктов в сервисе */
    public function stepSyncExportUpdProduct($data = array())
    {
        if (!$this->getOption('process_product_on_export_upd')) {
            return parent::stepSyncExportUpdProduct();
        }

        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent:!=" => "",
        ));
        $q->limit(1);
        $q->sortby("{$classSync}.sync_idx", "ASC");

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreProduct($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->updateData('product', $syncObject->get('sync_parent'), $row);
            $data = $response->getResponseBody();
            if ($response->isSuccessful()) {

                /* TODO */

            } else {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($data, true));
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUpdProduct();
    }

    /* экспорта создание продуктов в сервисе */
    public function stepSyncExportCreProduct($data = array())
    {
        $syncType = "product";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";

        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"      => $syncType,
            "{$classSync}.sync_action"    => $syncAction,
            "{$classSync}.sync_service"   => $this->syncService,
            "{$classSync}.sync_processed" => 0,
            "{$classSync}.sync_parent"    => "",
        ));
        $q->limit(1);

        $q->sortby("{$classSync}.sync_idx", "ASC");

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncObject */
        while ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncObject->set("sync_processed", true);
            $syncObject->save();

            if (!$row = $this->processSyncExportCreProduct($syncObject->toArray(), $syncType, $syncAction = "unload")) {
                continue;
            }

            $response = $this->SyncTools->createData('product', $row);
            $data = $response->getResponseBody();
            if ($response->isSuccessful()) {
                if ($r = $this->modx->getObject($classResource,
                    array('id' => (int)$syncObject->get('sync_resource')))
                ) {
                    $r->set("sync_service", $this->syncService);
                    $r->set("sync_id", $data['id']);
                    $r->set("sync_data", $data);
                    $r->save();
                }
            } else {
                $this->err++;
                $syncObject->set("sync_error", true);
                $syncObject->set("sync_error_msg", json_encode($data, true));
                $syncObject->save();
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportCreProduct();
    }


    /* подготовка существующих модификаций для обновления экспорта */
    public function stepSyncExportUnlModification($data = array())
    {
        if (!$this->getOption('modification_process_on_export_upd')) {
            return parent::stepSyncExportUnlModification();
        }

        $syncType = "modification";
        $syncAction = "export";
        $classSync = "syncObject";
        $classResource = "modResource";
        $classModification = "msopModification";

        $q = $this->modx->newQuery($classModification);
        $q->innerJoin($classResource, $classResource,
            "{$classResource}.id = {$classModification}.rid " .
            "AND {$classResource}.sync_service = {$classModification}.sync_service"
        );
        $q->leftJoin($classSync, $classSync,
            "{$classModification}.sync_id = {$classSync}.sync_id ".
            "AND {$classSync}.sync_action = '{$syncAction}'"
        );

        $parents = $this->getSyncResourceChilds();
        $q->where(array(
            "{$classResource}.parent:IN"    => $parents,
            "{$classResource}.published"    => $this->getOption("{$syncType}_published", null, 1, true),
            "{$classResource}.class_key"    => $this->getOption("{$syncType}_class_key", null, 'msProduct', true),
            "{$classResource}.sync_service" => $this->syncService,
            "{$classResource}.sync_id:!="   => "",
            "{$classResource}.deleted"      => 0,
            "{$classModification}.active"   => 1,
            "{$classModification}.type"     => 1,
            "{$classSync}.sync_resource"    => null,
        ));

        $q->limit(1);
        $q->groupby("{$classModification}.id");

        $alias = $q->getAlias();
        $q->select(array(
            "{$alias}.*",
            "{$classResource}.sync_id as sync_parent",
            "{$alias}.rid as sync_resource",
        ));

        $this->idx = $this->err = 0;
        /** @var xPDOObject $syncModification */
        while ($syncModification = $this->modx->getObject($classModification, $q)) {

            if (!$row = $this->processSyncExportUnlModification($syncModification->toArray(), $syncType, $syncAction)) {
                continue;
            }

            /** @var xPDOObject $object */
            if ($object = $this->createSyncObject($syncType, $syncAction, $row['sync_id'], $row)) {
                if ($object->save()) {
                }
            }

            $this->idx++;
            $this->nextSyncCount();
            if (!$this->processExpense() OR $this->idx >= $this->getOption('api_limit', null, 50)) {
                return $this->currentStep();
            }
        }

        return parent::stepSyncExportUnlModification();
    }

    /* TODO */
    /* обновление существующих модификаций экспорта */
    public function stepSyncExportUpdModification($data = array())
    {
        return parent::stepSyncExportUpdModification();
    }
    /* TODO */
    /* подготовка новых модификаций для обновления экспорта */
    public function stepSyncExportUnlNewModification($data = array())
    {
        return parent::stepSyncExportUnlNewModification();
    }
    /* TODO */
    /* создание новых модификаций экспорта */
    public function stepSyncExportCreModification($data = array())
    {
        return parent::stepSyncExportCreModification();
    }



    /********************* BASE FUNCTIONS *********************/
    /********************* BASE FUNCTIONS *********************/
    /********************* BASE FUNCTIONS *********************/
    public function createSyncObject($type = '', $action = '', $id, array $data = array(), $class = 'syncObject')
    {
        $object = parent::createSyncObject($type, $action, $id, $data, $class);

        return $object;
    }

    public function processSyncFilters($data = array())
    {
        $filters = array();

        if (!empty($data)) {
            $meta = (array)$this->modx->getOption('meta', $data);
            if ($nextHref = $this->modx->getOption('nextHref', $meta)) {
                $tmp = parse_url($nextHref);
                if (isset($tmp['query'])) {
                    parse_str($tmp['query'], $filters);
                    ksort($filters);
                }
            } elseif ($href = $this->modx->getOption('href', $meta)) {
                $size = (int)$this->modx->getOption('size', $meta);
                $limit = (int)$this->modx->getOption('limit', $meta);
                $offset = (int)$this->modx->getOption('offset', $meta);

                if ($size > ($offset + $limit)) {
                    $tmp = parse_url($href);
                    if (isset($tmp['query'])) {
                        parse_str($tmp['query'], $filters);
                        ksort($filters);
                        $filters['limit'] = $limit;
                        $filters['offset'] = $offset + $limit;
                    }
                }
            }


            /* $offset = (int)$this->modx->getOption('offset', $meta);
             if ($offset > 900) {
                 $filters = array();
             }*/

            $this->setSyncPropertiesValue("sync_meta", $meta);
            $this->setSyncFilters($filters);
        }

        return $filters;
    }


    /************************ READ ************************/
    public function processSyncReadCategory($row, $syncType, $syncAction)
    {
        $syncName = $this->modx->getOption('name', $row, "", true);
        $syncParent = $this->modx->getOption('pathName', $row, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadProduct($row, $syncType, $syncAction)
    {
        $syncName = $this->modx->getOption('name', $row, "", true);
        $syncParent = $this->modx->getOption('pathName', $row, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadModification($row, $syncType, $syncAction)
    {
        $product = $this->modx->getOption('product', $row, array(), true);
        $syncParent = $this->getSyncObjectUuid($product);

        $classResource = "modResource";
        $q = $this->modx->newQuery($classResource);
        $q->where(array(
            "{$classResource}.sync_id"      => $syncParent,
            "{$classResource}.sync_service" => $this->syncService,
        ));
        $q->select("{$classResource}.id");

        if (!$syncResource = $this->modx->getValue($q->prepare())) {
            return null;
        };

        $row = array_merge(array(
            "sync_parent"   => $syncParent,
            "sync_resource" => $syncResource
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncReadProductStock($row, $syncType, $syncAction)
    {
        $folder = $this->modx->getOption('folder', $row, array(), true);
        $syncName = $this->modx->getOption('name', $folder, "", true);
        $syncParent = $this->modx->getOption('pathName', $folder, "", true);
        if (empty($syncParent)) {
            $syncPath = $syncName;
        } else {
            $syncPath = $syncParent . '/' . $syncName;
        }

        $row = array_merge(array(
            "id"          => $this->getSyncObjectUuid($row),
            "sync_parent" => $syncParent,
            "sync_path"   => $syncPath,
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }


    /************************ IMPORT ************************/
    public function processSyncImportCategoryObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $classSync = "syncObject";
        $classResource = "modResource";

        $syncData = $this->modx->getOption('sync_data', $row);

        $name = $this->modx->getOption('name', $syncData);
        $syncParent = $this->modx->getOption('sync_parent', $row);

        if (!$this->getSyncResourceImportFolder($name, $syncParent)) {
            return null;
        }

        $row = array_merge(array(
            "pagetitle"             => $name,
            "parent"                => $this->getOption("sync_parent", null, 0, true),
            "class_key"             => $this->getOption("{$syncType}_class_key", null, "msCategory", true),
            "context_key"           => $this->getOption("{$syncType}_context_key", null, "web", true),
            "content_type"          => $this->getOption("{$syncType}_content_type", null, 1, true),
            "template"              => $this->getOption("{$syncType}_template", null, 1, true),
            "published"             => $this->getOption("{$syncType}_published", null, 1, true),
            "isfolder"              => $this->getOption("{$syncType}_isfolder", null, 1, true),
            "richtext"              => $this->getOption("{$syncType}_richtext", null, 1, true),
            "createdby"             => $this->getOption("{$syncType}_createdby", null, 1, true),
            "show_in_tree"          => $this->getOption("{$syncType}_show_in_tree", null, 1, true),
            "hide_children_in_tree" => $this->getOption("{$syncType}_hide_children_in_tree", null, 0, true),
        ), $row);


        /* set parent by $syncParent */
        if (!empty($syncParent)) {
            $q = $this->modx->newQuery($classSync);
            $q->innerJoin($classResource, $classResource,
                "{$classResource}.sync_id = {$classSync}.sync_id " .
                "AND {$classResource}.sync_service = {$classSync}.sync_service"
            );
            $q->where(array(
                "{$classSync}.sync_type"    => $syncType,
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncParent,
            ));
            $q->select("{$classResource}.id");
            if ($parent = $this->modx->getValue($q->prepare())) {
                $row["parent"] = $parent;
            };
        }

        $fields = $this->getOption('category_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }

        /* set published by $archived */
        $archived = (bool)$this->modx->getOption('archived', $syncData);
        if ($archived) {
            $row["published"] = $this->getOption("{$syncType}_archived_published", null, 0, true);
        }

        return $row;
        //return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportUpdCategory($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportCategoryObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportCreCategory($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportCategoryObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }


    public function processSyncImportProductObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $classSync = "syncObject";
        $classResource = "modResource";

        $syncData = $this->modx->getOption('sync_data', $row);

        $name = $this->modx->getOption('name', $syncData);
        $syncParent = $this->modx->getOption('sync_parent', $row);
        if (!$this->getSyncResourceImportFolder($name, $syncParent)) {
            return null;
        }

        $row = array_merge(array(
            "pagetitle"             => $name,
            "parent"                => $this->getOption("sync_parent", null, 0, true),
            "class_key"             => $this->getOption("{$syncType}_class_key", null, "msProduct", true),
            "context_key"           => $this->getOption("{$syncType}_context_key", null, "web", true),
            "content_type"          => $this->getOption("{$syncType}_content_type", null, 1, true),
            "template"              => $this->getOption("{$syncType}_template", null, 1, true),
            "published"             => $this->getOption("{$syncType}_published", null, 1, true),
            "isfolder"              => $this->getOption("{$syncType}_isfolder", null, 0, true),
            "richtext"              => $this->getOption("{$syncType}_richtext", null, 1, true),
            "createdby"             => $this->getOption("{$syncType}_createdby", null, 1, true),
            "show_in_tree"          => $this->getOption("{$syncType}_show_in_tree", null, 0, true),
            "hide_children_in_tree" => $this->getOption("{$syncType}_hide_children_in_tree", null, 0, true),
        ), $row);

        /* set parent by $syncParent */
        if (!empty($syncParent)) {
            $q = $this->modx->newQuery($classSync);
            $q->innerJoin($classResource, $classResource,
                "{$classResource}.sync_id = {$classSync}.sync_id " .
                "AND {$classResource}.sync_service = {$classSync}.sync_service"
            );
            $q->where(array(
                "{$classSync}.sync_type"    => "category",
                "{$classSync}.sync_action"  => $syncAction,
                "{$classSync}.sync_service" => $this->syncService,
                "{$classSync}.sync_path"    => $syncParent,
            ));
            $q->select("{$classResource}.id");
            if ($parent = $this->modx->getValue($q->prepare())) {
                $row["parent"] = $parent;
            };
        }

        /* process main fields */
        $fields = $this->getOption('product_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }


        /**********************************************************************/
        /* set country */
        $country = $this->modx->getOption('country', $syncData, array(), true);
        if (isset($country['name'])) {
            $row["made_in"] = $country['name'];
        }
        /* set published by $archived */
        $archived = (bool)$this->modx->getOption('archived', $syncData);
        if ($archived) {
            $row["published"] = $this->getOption("{$syncType}_archived_published", null, 0, true);
        }

        return $row;
    }

    public function processSyncImportProductStockObject($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $fields = $this->getOption('product_stock', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $row[$k] = $this->prepareImportValue($value, $type);
            }
        }

        return $row;
    }


    public function processSyncImportUpdProduct($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('process_image') AND $this->getOption('process_image_on_import_upd')) {
            $row["sync_images"] = $this->processSyncImportImage($syncData);
        }

        if ($this->getOption('process_product_attributes') AND $this->getOption('process_product_attributes_on_import')) {
            $attributes = $this->processSyncImportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('process_product_price_on_import')) {
            $price = $this->processSyncImportPrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportCreProduct($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        if ($this->getOption('process_image') AND $this->getOption('process_image_on_import_cre')) {
            $row["sync_images"] = $this->processSyncImportImage($syncData);
        }

        if ($this->getOption('process_product_attributes') AND $this->getOption('process_product_attributes_on_import')) {
            $attributes = $this->processSyncImportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('process_product_price_on_import')) {
            $price = $this->processSyncImportPrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncImportModification($row, $syncType, $syncAction)
    {
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        $modification = array(
            'sync_id'      => $this->modx->getOption('sync_id', $row),
            'sync_service' => $this->modx->getOption('sync_service', $row)
        );

        /* process main fields */
        $fields = $this->getOption('modification_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($key, $syncData);
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $modification[$k] = $this->prepareImportValue($value, $type);
            }
        }

        /* process characteristics */
        if (!$characteristics = $this->modx->getOption('characteristics', $syncData)) {
            return null;
        }

        $options = array();
        $fields = $this->getOption('modification_characteristics', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($characteristics, array('name' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $options[$k] = $this->prepareImportAttrValue($value, $type);
            }
        }

        if (empty($options)) {
            return null;
        }
        $modification['options'] = $options;

        /* process price */
        $prices = $this->modx->getOption('salePrices', $syncData, array(), true);
        $rate = $this->getSyncResourcePriceRate();
        $fields = $this->getOption('modification_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($prices, array('priceType' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $modification[$k] = $this->prepareImportAttrValue($value, $type) / $rate;
            }
        }

        return parent::processSyncObject($modification, $syncType, $syncAction);
    }

    //

    public function processSyncImportUpdProductStock($row, $syncType, $syncAction)
    {
        if (!$row = $this->processSyncImportProductStockObject($row, $syncType, $syncAction)) {
            return null;
        }
        /* check sync_data */
        if (!$syncData = $this->modx->getOption('sync_data', $row)) {
            return null;
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    /************************ ADD ************************/
    public function processSyncImportImage($row)
    {
        $image = null;
        if (isset($row['image'])) {
            $image = $this->SyncTools->getFile($row['image']);
            if (!empty($image)) {
                $image = array($image);
            }
        }

        return $image;
    }

    public function processSyncExportImage($row)
    {
        $image = null;
        if (isset($row['image'])) {
            $image = $this->SyncTools->setFile($row['image']);
        }

        return $image;
    }

    /* TODO */
    public function processSyncImportAttributes($row)
    {
        $data = array();
        $attributes = $this->modx->getOption('attributes', $row, array(), true);

        $fields = $this->getOption('product_attributes', null, array(), true);
        $fields = json_decode($fields, true);

        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('name' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type);
            }
        }

        return $data;
    }

    /* TODO */
    public function processSyncExportAttributes($row)
    {
        $attributes = array();

        $fields = $this->getOption('product_attributes', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportAttrValue($value, $type, $key);
            if (!is_null($value)) {
                $attributes[] = $value;
            }
        }

        return array('attributes' => $attributes);
    }


    public function getSyncResourcePriceRate()
    {
        $rate = 0;

        $currency = $this->getOption('currency', null, 643);
        $syncType = "currency";
        $syncAction = "import";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_id"      => $currency,
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_action"  => $syncAction,
            "{$classSync}.sync_service" => $this->syncService,
        ));
        $q->limit(1);

        if ($syncObject = $this->modx->getObject($classSync, $q)) {
            $syncData = $syncObject->get('sync_data');
            $rate = $this->getOption('rate', $syncData, 1, true);
        }
        if (empty($rate)) {
            $rate = 1;
        }
        $rate = $rate * $this->getOption('currency_rate', null, 1, true);

        return $rate;
    }


    /* TODO */
    public function processSyncImportPrice($row)
    {
        $data = array();

        $attributes = $this->modx->getOption('salePrices', $row, array(), true);
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('product_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->Sync->getArrayValue($attributes, array('priceType' => $key));
            if (is_null($value)) {
                $value = $this->modx->getOption('value', $v);
            }
            if (!is_null($value)) {
                $data[$k] = $this->prepareImportAttrValue($value, $type) / $rate;
            }
        }

        return $data;
    }

    /* TODO */
    public function processSyncExportPrice($row)
    {
        $data = array();
        $rate = $this->getSyncResourcePriceRate();

        $fields = $this->getOption('product_price', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $row);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $data[] = array(
                    "value"     => (float)$value * $rate,
                    "priceType" => $key
                );
            }
        }

        return array('salePrices' => $data);
    }


    /************************ EXPORT ************************/
    public function processSyncExportUnlCategory($row, $syncType, $syncAction)
    {
        $row = array_merge(array(
            "sync_resource" => $this->modx->getOption('id', $row),
        ), $row);

        $row["sync_data"] = array();

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportUnlProduct($row, $syncType, $syncAction)
    {
        $row = array_merge(array(
            "sync_resource" => $this->modx->getOption('id', $row),
        ), $row);

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    /* TODO */
    public function processSyncExportUnlModification($row, $syncType, $syncAction)
    {
        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function processSyncExportCreCategory($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description');
        $fields = $this->getOption('category_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }
            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);
            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    /**
     * @param $row
     * @param $syncType
     * @param $syncAction
     *
     * @return array|null
     */
    public function processSyncExportCreProduct($row, $syncType, $syncAction)
    {
        $classResource = "modResource";
        $syncData = $this->modx->getOption('sync_data', $row);
        $syncParent = $this->modx->getOption('parent', $syncData);

        $row = array(
            "name"        => (string)$this->modx->getOption('name', $row,
                $this->modx->getOption('pagetitle', $syncData)),
            "description" => (string)$this->modx->getOption('description', $row,
                $this->modx->getOption('description', $syncData)),
            "article"     => (string)$this->modx->getOption('article', $row,
                $this->modx->getOption('article', $syncData)),
            "weight"      => (float)$this->modx->getOption('weight', $row, $this->modx->getOption('weight', $syncData)),
            "volume"      => (float)$this->modx->getOption('volume', $row, $this->modx->getOption('volume', $syncData)),
        );

        if ($syncMeta = $this->getSyncResourceParentSyncMeta($syncParent)) {
            $row["productFolder"] = array('meta' => $syncMeta);
        }

        $allowedFields = array('name', 'description', 'article', 'code', 'externalCode', 'weight', 'volume');
        $fields = $this->getOption('product_fields', null, array(), true);
        $fields = json_decode($fields, true);
        foreach ($fields as $k => $v) {
            $key = $this->modx->getOption('key', $v);
            if (!in_array($key, $allowedFields)) {
                continue;
            }

            $type = $this->modx->getOption('type', $v, 'string', true);
            $value = $this->modx->getOption($k, $syncData);
            $value = $this->prepareExportValue($value, $type, $key);

            if (!is_null($value)) {
                $row[$key] = $value;
            }
        }

        if ($this->getOption('process_image') AND $this->getOption('process_image_on_export_cre')) {
            $row["image"] = $this->processSyncExportImage($syncData);
        }

        if ($this->getOption('process_product_attributes') AND $this->getOption('process_product_attributes_on_export')) {
            $attributes = $this->processSyncExportAttributes($syncData);
            $row = array_merge($row, $attributes);
        }

        if ($this->getOption('process_price') AND $this->getOption('process_product_price_on_export')) {
            $price = $this->processSyncExportPrice($syncData);
            $row = array_merge($row, $price);
        }

        return parent::processSyncObject($row, $syncType, $syncAction);
    }

    public function prepareImportValue($v = null, $type = 'string')
    {
        return $this->SyncTools->prepareValue($v, $type);
    }

    public function prepareImportAttrValue($v = null, $type = 'string')
    {
        return $this->SyncTools->prepareValue($v, $type);
    }

    public function prepareExportValue($v = null, $type = 'string', $key = '')
    {
        switch ($type) {
            case 'array':
                switch (true) {
                    case is_array($v):
                        $v = $this->Sync->cleanAndImplode($v);
                        break;
                }
                break;
            default:
                break;
        }

        switch ($key) {
            case 'name':
            case 'description':
            case 'article':
            case 'code':
            case 'externalCode':
                $v = (string)$v;
                break;
            case 'weight':
            case 'volume':
                $v = (float)$v;
                break;
            default:
                $v = (string)$v;
        }

        return $v;
    }

    public function prepareExportAttrValue($v = null, $type = 'string', $key = '')
    {
        $syncType = "product_metadata_attribute";
        $classSync = "syncObject";
        $q = $this->modx->newQuery($classSync);
        $q->where(array(
            "{$classSync}.sync_type"    => $syncType,
            "{$classSync}.sync_service" => $this->syncService,
            "{$classSync}.sync_parent"  => $key,
        ));
        $q->limit(1);

        $q->select('sync_id');
        if ($stmt = $q->prepare() AND $syncId = $this->modx->getValue($stmt)) {
            $v = array(
                "id"    => $syncId,
                "name"  => $key,
                "value" => $this->prepareExportValue($v, $type, $key)
            );
        } else {
            $v = null;
        }

        return $v;
    }

}

return 'modSyncMoySkladSyncProcessor';