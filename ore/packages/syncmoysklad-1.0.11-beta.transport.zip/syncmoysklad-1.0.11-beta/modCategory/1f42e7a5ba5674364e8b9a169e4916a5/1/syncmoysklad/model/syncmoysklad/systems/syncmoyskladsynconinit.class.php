<?php

class syncMoySkladsyncOnInit extends syncMoySkladPlugin
{
    public function run()
    {
        if (isset($this->modx->controller)) {
            $this->modx->controller->addLexiconTopic('syncmoysklad:default');
        }
    }
}