<?php

//ini_set('display_errors', 1);
//ini_set('error_reporting', -1);

ini_set('apc.cache_by_default', 'Off');

/** @var mixed|null $service */
$service = 'moysklad';

$stream = file_get_contents('php://input');
$stream = json_decode($stream, true);

define('MODX_REQP', false);
define('MODX_API_MODE', true);
define('MODX_ACTION_MODE', true);

$productionConfig = dirname(dirname(dirname(dirname(__FILE__)))) . '/config.core.php';
$developmentConfig = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/config.core.php';
if (file_exists($productionConfig)) {
    /** @noinspection PhpIncludeInspection */
    require_once $productionConfig;
} else {
    /** @noinspection PhpIncludeInspection */
    require_once $developmentConfig;
}
/** @noinspection PhpIncludeInspection */
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
/** @noinspection PhpIncludeInspection */
require_once MODX_CONNECTORS_PATH . 'index.php';


$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');
$modx->error->message = null;

/** @var Sync $Sync */
$Sync = $modx->getService('sync', 'Sync',
    $modx->getOption('sync_core_path', null,
        $modx->getOption('core_path') . 'components/sync/') . 'model/sync/');
$corePath = $modx->getOption('sync_core_path', null, $modx->getOption('core_path') . 'components/sync/');
$modx->lexicon->load('sync:default');

if (!$Sync->loadSyncTools($service)) {
    die('Error load SyncTools');
}

/** @var SyncMoySkladTools $SyncTools */
$SyncTools = &$Sync->SyncTools;

/* Auth */
$auth = $modx->getOption('auth', $_REQUEST, ':', true);
$auth = explode(':', base64_decode($auth));
$SyncTools->processSyncAuth(array('username' => @$auth[0], 'password' => @$auth[1]));

$events = $modx->getOption('events', $stream, array(), true);
foreach ($events as $event) {
    $meta = $modx->getOption('meta', $event);
    $syncType = $modx->getOption('type', $meta);
    $syncAction = strtolower($modx->getOption('action', $event));
    $event = array_merge($event, array(
        'sync_id'   => $SyncTools->getUuidByMeta($meta),
        'class_key' => 'event',
    ));
    $event = $SyncTools->processSyncObject($event, $syncType, $syncAction);
}

@session_write_close();
echo '';