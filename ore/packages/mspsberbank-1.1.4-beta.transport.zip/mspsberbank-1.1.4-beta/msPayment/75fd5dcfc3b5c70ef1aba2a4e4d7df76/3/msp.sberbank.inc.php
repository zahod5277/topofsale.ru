<?php

$_lang['setting_ms2_payment_sbrbnk_url'] = 'Адрес для запросов';
$_lang['setting_ms2_payment_sbrbnk_url_desc'] = 'Адрес для отправки запросов на удалённый сервис Сбербанка';

$_lang['setting_ms2_payment_sbrbnk_login'] = 'Логин Сбербанка';
$_lang['setting_ms2_payment_sbrbnk_login_desc'] = 'Логин в системе Сбербанка.';

$_lang['setting_ms2_payment_sbrbnk_pass'] = 'Пароль Сбербанка';
$_lang['setting_ms2_payment_sbrbnk_pass_desc'] = 'Пароль в системе Сбербанка.';
/*
$_lang['setting_ms2_payment_sbrbnk_pass2'] = 'Пароль №2';
$_lang['setting_ms2_payment_sbrbnk_pass2_desc'] = 'Используется интерфейсом оповещения о платеже, XML-интерфейсами.';
*/
$_lang['setting_ms2_payment_sbrbnk_currency'] = 'Валюта платежа';
$_lang['setting_ms2_payment_sbrbnk_currency_desc'] = 'Предлагаемая валюта платежа. ';

$_lang['setting_ms2_payment_sbrbnk_culture'] = 'Язык Сбербанка';
$_lang['setting_ms2_payment_sbrbnk_culture_desc'] = 'Укажите код языка, на котором показывать сайт Сбербанка при оплате.';

$_lang['setting_ms2_payment_sbrbnk_success_id'] = 'Страница успешной оплаты Сбербанка';
$_lang['setting_ms2_payment_sbrbnk_success_id_desc'] = 'Пользователь будет отправлен на эту страницу после завершения оплаты. Рекомендуется указать id страницы с корзиной, для вывода заказа.';

$_lang['setting_ms2_payment_sbrbnk_failure_id'] = 'Страница отказа от оплаты Сбербанка';
$_lang['setting_ms2_payment_sbrbnk_failure_id_desc'] = 'Пользователь будет отправлен на эту страницу при неудачной оплате. Рекомендуется указать id страницы с корзиной, для вывода заказа';
