Ext.namespace('sync.combo');


sync.combo.Parent = function(config) {
	config = config || {};

	if (config.custm) {
		config.triggerConfig = [{
			tag: 'div',
			cls: 'x-field-search-btns',
			style: String.format('width: {0}px;', config.clear?62:31),
			cn: [{
				tag: 'div',
				cls: 'x-form-trigger x-field-sync-parent-go'
			}]
		}];
		if (config.clear) {
			config.triggerConfig[0].cn.push({
				tag: 'div',
				cls: 'x-form-trigger x-field-sync-parent-clear'
			});
		}

		config.initTrigger = function() {
			var ts = this.trigger.select('.x-form-trigger', true);
			this.wrap.setStyle('overflow', 'hidden');
			var triggerField = this;
			ts.each(function(t, all, index) {
				t.hide = function() {
					var w = triggerField.wrap.getWidth();
					this.dom.style.display = 'none';
					triggerField.el.setWidth(w - triggerField.trigger.getWidth());
				};
				t.show = function() {
					var w = triggerField.wrap.getWidth();
					this.dom.style.display = '';
					triggerField.el.setWidth(w - triggerField.trigger.getWidth());
				};
				var triggerIndex = 'Trigger' + (index + 1);

				if (this['hide' + triggerIndex]) {
					t.dom.style.display = 'none';
				}
				t.on('click', this['on' + triggerIndex + 'Click'], this, {
					preventDefault: true
				});
				t.addClassOnOver('x-form-trigger-over');
				t.addClassOnClick('x-form-trigger-click');
			}, this);
			this.triggers = ts.elements;
		};
	}
	Ext.applyIf(config, {
		name: config.name || 'parent',
		hiddenName: config.name || 'parent',
		displayField: 'name',
		valueField: 'id',
		editable: true,
		fields: ['name', 'id'],
		pageSize: 10,
		emptyText: _('sync_combo_select'),
		hideMode: 'offsets',
		url: sync.config.connector_url,
		baseParams: {
			action: 'mgr/misc/parent/getlist',
			combo: true,
			addall: config.addall || 0
		},
		tpl: new Ext.XTemplate(
			'<tpl for="."><div class="x-combo-list-item">',
			'<small>({id})</small> <b>{name}</b>',
			'</div></tpl>',
			{
				compiled: true
			}),
		cls: 'input-combo-sync-parent',
		clearValue: function() {
			if (this.hiddenField) {
				this.hiddenField.value = '';
			}
			this.setRawValue('');
			this.lastSelectionText = '';
			this.applyEmptyText();
			this.value = '';
			this.fireEvent('select', this, null, 0);
		},

		getTrigger: function(index) {
			return this.triggers[index];
		},

		onTrigger1Click: function() {
			this.onTriggerClick();
		},

		onTrigger2Click: function() {
			this.clearValue();
		}
	});
	sync.combo.Parent.superclass.constructor.call(this, config);

};
Ext.extend(sync.combo.Parent, MODx.combo.ComboBox);
Ext.reg('sync-combo-parent', sync.combo.Parent);
