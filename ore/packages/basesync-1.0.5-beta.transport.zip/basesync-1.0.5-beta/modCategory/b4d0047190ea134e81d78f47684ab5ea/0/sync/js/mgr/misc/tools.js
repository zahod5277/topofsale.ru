sync.tools.getMenu = function (actions, grid, selected) {
	var menu = [];
	var cls, icon, title, action = '';

	for (var i in actions) {
		if (!actions.hasOwnProperty(i)) {
			continue;
		}

		var a = actions[i];
		if (!a['menu']) {
			if (a == '-') {
				menu.push('-');
			}
			continue;
		} else if (menu.length > 0 && (/^sep/i.test(a['action']))) {
			menu.push('-');
			continue;
		}

		if (selected.length > 1) {
			if (!a['multiple']) {
				continue;
			} else if (typeof(a['multiple']) == 'string') {
				a['title'] = a['multiple'];
			}
		}

		cls = a['cls'] ? a['cls'] : '';
		icon = a['icon'] ? a['icon'] : '';
		title = a['title'] ? a['title'] : a['title'];
		action = a['action'] ? grid[a['action']] : '';

		menu.push({
			handler: action,
			text: String.format(
				'<span class="{0}"><i class="x-menu-item-icon {1}"></i>{2}</span>',
				cls, icon, title
			)
		});
	}

	return menu;
};


sync.tools.renderActions = function (value, props, row) {
	var res = [];
	var cls, icon, title, action, item = '';
	for (var i in row.data.actions) {
		if (!row.data.actions.hasOwnProperty(i)) {
			continue;
		}
		var a = row.data.actions[i];
		if (!a['button']) {
			continue;
		}

		cls = a['cls'] ? a['cls'] : '';
		icon = a['icon'] ? a['icon'] : '';
		action = a['action'] ? a['action'] : '';
		title = a['title'] ? a['title'] : '';

		item = String.format(
			'<li class="{0}"><button class="btn btn-default {1}" action="{2}" title="{3}"></button></li>',
			cls, icon, action, title
		);

		res.push(item);
	}

	return String.format(
		'<ul class="sync-row-actions">{0}</ul>',
		res.join('')
	);
};


sync.tools.handleChecked = function (checkbox) {
	var workCount = checkbox.workCount;
	if (!!!workCount) {
		workCount = 1;
	}
	var hideLabel = checkbox.hideLabel;
	if (!!!hideLabel) {
		hideLabel = false;
	}
	var disableWork = checkbox.disableWork;
	if (disableWork == undefined) {
		disableWork = true;
	}

	var checked = checkbox.getValue();
	var nextField = checkbox.nextSibling();

	for (var i = 0; i < workCount; i++) {
		if (checked) {
			nextField.show().enable();
		}
		else {
			if (disableWork) {
				nextField.hide().disable();
			}
			else {
				nextField.hide();
			}
		}
		nextField.hideLabel = hideLabel;
		nextField = nextField.nextSibling();
	}
	return true;
};


sync.tools.arrayIntersect = function (array1, array2) {
	var result = array1.filter(function (n) {
		return array2.indexOf(n) !== -1;
	});

	return result;
};

sync.tools.inArray = function (needle, haystack) {
	for (key in haystack) {
		if (haystack[key] == needle) return true;
	}

	return false;
};


sync.tools.renderReplace = function (value, replace, color) {
	if (!value) {
		return '';
	} else if (!replace) {
		return value;
	}
	if (!color) {
		return String.format('<span>{0}</span>', replace);
	}
	return String.format('<span class="sync-render-replace" style="color: #{1}">{0}</span>', replace, color);
};


sync.tools.empty = function (value) {
	return (typeof(value) == 'undefined' || value == 0 || value === null || value === false || (typeof(value) == 'string' && value.replace(/\s+/g, '') == '') || (typeof(value) == 'object' && value.length == 0));
};


sync.tools.versionCompare = function (version1, version2, comparator) {
	if (typeof version1 + typeof version2 != 'stringstring') {
		return false;
	}

	var comparator = comparator == '=' ? '==' : comparator;
	if (['==', '===', '<', '<=', '>', '>=', '!=', '!=='].indexOf(comparator) == -1) {
		throw new Error('Invalid comparator. ' + comparator);
	}

	var regExStrip0 = /(\.0+)+$/;

	var a = version1.replace(regExStrip0, '').split('.');
	var b = version2.replace(regExStrip0, '').split('.');

	var cmp = 0;
	var len = Math.max(a.length, b.length);

	for (var i = 0; i < len && !cmp; i++) {
		part1 = parseInt(a[i], 10) || 0;
		part2 = parseInt(b[i], 10) || 0;
		if (part1 < part2)
			cmp = 1;
		if (part1 > part2)
			cmp = -1;
	}

	return eval('0' + comparator + cmp);
};


sync.tools.renderSyncResponse = function (response, self, clear) {
	try {
		var message = response.message || '';
		var level = response.level || '';

		if(sync.tools.empty(message) && !clear){
			level = 1;
			message = MODx.lang['sync_err_empty'] || '';
		}
		
		var cls = '';
		switch (level) {
			case 1:
				cls = 'error';
				break;
			case 2:
				cls = 'warn';
				break;
			case 3:
				cls = 'info';
				break;
			case 4:
				cls = 'debug';
				break;
		}

		if (message) {
			message = String.format('<p class="sync-response {0}">{1}</p>', cls, message);
		}

		if (self) {
			var body = self.getComponent('body');
			if (body && clear) {
				body.el.dom.innerHTML = '';
			}

			if (body && message) {
				body.el.insertHtml('afterBegin', message);
				body.el.scroll('b', body.el.getHeight(), true);

				console.info(response);
			}
		}
		else {
			console.log(message);
		}
	}
	catch (e) {
		console.log(e);
		return false;
	}
};
