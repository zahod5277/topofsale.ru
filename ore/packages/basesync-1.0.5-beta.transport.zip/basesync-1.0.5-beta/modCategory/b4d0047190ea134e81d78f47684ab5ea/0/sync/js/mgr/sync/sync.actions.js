sync.actions.sync = function (btn, e) {

	var service = btn.service || 'sync';
	var action = btn.action || 'sync';
	var step = btn.step || 'sync_init';
	var resource = btn.resource || 0;

	var record = {
		service: service,
		action: 'mgr/' + action,
		sync_step: step,
		sync_resource: resource,
	};

	MODx.load({
		xtype: 'sync-window-sync',
		action: 'mgr/sync/sync',
		record: record,
		listeners: {
			success: {
				fn: function (r) {

				},
				scope: this
			},
			failure: {
				fn: function (response) {
					MODx.msg.alert(_('error'), response.message);
				},
				scope: this
			}
		}
	}).show(e.target);

};

