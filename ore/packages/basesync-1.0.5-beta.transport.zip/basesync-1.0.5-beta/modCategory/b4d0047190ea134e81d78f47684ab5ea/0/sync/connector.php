<?php

//ini_set('display_errors', 1);
//ini_set('error_reporting', -1);

ini_set('apc.cache_by_default', 'Off');

$productionConfig = dirname(dirname(dirname(dirname(__FILE__)))) . '/config.core.php';
$developmentConfig = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/config.core.php';
if (file_exists($productionConfig)) {
    /** @noinspection PhpIncludeInspection */
    require_once $productionConfig;
} else {
    /** @noinspection PhpIncludeInspection */
    require_once $developmentConfig;
}
/** @noinspection PhpIncludeInspection */
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
/** @noinspection PhpIncludeInspection */
require_once MODX_CONNECTORS_PATH . 'index.php';

/** @var Sync $Sync */
$Sync = $modx->getService('sync', 'Sync',
    $modx->getOption('sync_core_path', null,
        $modx->getOption('core_path') . 'components/sync/') . 'model/sync/');
$modx->lexicon->load('sync:default');

$service = $modx->getOption('service', $_REQUEST, 'sync', true);
$corePath = $modx->getOption('sync_core_path', null, $modx->getOption('core_path') . 'components/sync/');
$corePath = $Sync->getServiceCorePath($service, $corePath);

/** @var modConnectorRequest $request */
$request = $modx->request;
$request->handleRequest(array(
    'processors_path' => $corePath . 'processors/',
    'location'        => '',
));