sync.panel.ResourceSync = function(config) {
	config = config || {};

	Ext.apply(config, {
		id: 'sync-panel-resource-sync',
		forceLayout: true,
		deferredRender: false,
		autoHeight: true,
		border: false,
		bodyCssClass: 'tab-panel-wrapper form-with-labels',

		/*
		 глючит грид в табе
		 stateful: true,
		 stateId: 'sync-panel-sync-tabs',
		 stateEvents: ['tabchange'],
		 getState: function() {
		 return {activeTab: this.items.indexOf(this.getActiveTab())};
		 },*/

		items: this.getTabs(config)
	});

	if (!config.update) {
		config.update = false;
	}

	sync.panel.ResourceSync.superclass.constructor.call(this, config);
};
Ext.extend(sync.panel.ResourceSync, MODx.VerticalTabs, {


	getTabs: function(config) {
		config.listeners = {
			change: {
				fn: MODx.fireResourceFormChange
			},
			select: {
				fn: MODx.fireResourceFormChange
			},
			keydown: {
				fn: MODx.fireResourceFormChange
			},
			check: {
				fn: MODx.fireResourceFormChange
			},
			uncheck: {
				fn: MODx.fireResourceFormChange
			}
		};

		var tabs = [{
			title: _('sync_tab_main'),
			hideMode: 'offsets',
			anchor: '100%',
			layout: 'form',
			defaults: {
				layout: 'form',
				labelAlign: 'top',
				anchor: '100%',
				border: false,
				labelSeparator: ''
			},
			items: this.getMainFields(config)
		}];

		return tabs;
	},

	getTbarMainMenu: function(config) {
		var menu = [];

		return menu;
	},

	getTbarMain: function(config) {
		var tbar = [];

		return [{
			cls: 'sync-panel-resource-sync-tbar',
			anchor: '100%',
			border: false,
			items: [{tbar: tbar}]
		}];
	},

	getMainFields: function(config) {
		var fields = [];

		fields.push({
			layout: 'column',
			defaults: {
				layout: 'form',
				labelAlign: 'top',
				anchor: '100%',
				border: false,
				labelSeparator: ''
			},
			items: [{
				columnWidth: .7,
				items: this.getLeftMain(config)
			}, {
				columnWidth: .3,
				items: this.getRightMain(config)
			}]
		});

		fields.push({
			layout: 'column',
			defaults: {
				layout: 'form',
				labelAlign: 'top',
				anchor: '100%',
				border: false,
				labelSeparator: ''
			},
			items: [{
				columnWidth: 1,
				items: [{
					xtype: 'textarea',
					fieldLabel: _('sync_data'),
					name: 'sync_data',
					anchor: '100%',
					height: 300,
					grow: false,
					value: config.record['sync_data'] || '',
					listeners: config.listeners,
					setValue: function(value) {
						return Ext.form.TextField.superclass.setValue.call(this, Ext.util.JSON.encode(value));
					},
				}]
			}]
		});

		return fields;
	},

	getLeftMain: function(config) {
		return [{
			xtype: 'textfield',
			fieldLabel: _('sync_id'),
			name: 'sync_id',
			value: config.record['sync_id'] || '',
			anchor: '100%',
			allowBlank: true,
			listeners: config.listeners
		}];
	},

	getRightMain: function(config) {
		return [{
			xtype: 'textfield',
			fieldLabel: _('sync_service'),
			name: 'sync_service',
			value: config.record['sync_service'] || '',
			anchor: '100%',
			allowBlank: true,
			listeners: config.listeners
		}];
	},

});

Ext.reg('sync-panel-resource-sync', sync.panel.ResourceSync);

