sync.window.sync = function (config) {
	config = config || {};

	Ext.Ajax.timeout = 0;
	Ext.applyIf(config, {
		title: _('sync'),
		modal: Ext.isIE ? false : true,
		width: 600,
		height: 400,
		layout: 'auto',
		closeAction: 'close',
		shadow: true,
		resizable: false,
		collapsible: true,
		maximizable: false,
		autoHeight: false,
		autoScroll: true,
		refreshRate: 2,

		cls: 'sync-window-sync',
		items: this.getFields(config),
		listeners: this.getListeners(config),

		keys: this.getKeys(config),
		//buttons: this.getButtons(config),
		buttons: null,
		bbar: this.getButtons(config),

		url: sync.config['connector_url'],
		baseParams: {}
	});

	sync.window.sync.superclass.constructor.call(this, config);
	this.config = config;

	this.on('show', this.startAction);
};
Ext.extend(sync.window.sync, MODx.Window, {
	baseParams: {},
	stop: false,

	getFields: function (config) {
		return [{
			itemId: 'header',
			cls: 'modx-console-text',
			html: _('sync_step_sync_running'),
			border: false
		}, {
			xtype: 'panel',
			itemId: 'body',
			cls: 'x-panel-bwrap modx-console-text',
			border: false
		}];
	},

	getButtons: function (config) {
		var buttons = [];

		var component = [
			'category', 'left', 'start', 'stop'
		];

		var add = {
			category: {
				xtype: 'sync-combo-parent',
				cls: 'sync-parent',
				width: 190,
				addall: true,
				name: 'parent',
				listeners: {
					select: {
						fn: function (combo, value) {
							var v = combo.getValue();

							this.record['sync_resource'] = v;
							this.setBaseParams({sync_resource: v});
						},
						scope: this
					}
				}
			},
			left: '->',
			start: {
				handler: this.startAction,
				scope: this
			},
			stop: {
				handler: this.stopAction,
				scope: this
			}
		};

		component.filter(function (field) {
			if (add[field]) {

				var l = Ext.applyIf(add[field]['listeners'] || {}, {
					render: function (b) {
						var t = _('sync_tooltip_' + field);
						if (t) {
							Ext.QuickTips.register({
								target: b,
								text: t,
							});
						}
					}
				});

				Ext.applyIf(add[field], {
					text: _('sync_button_' + field),
					name: field,
					listeners: l
				});
				buttons.push(add[field]);
			}
		});

		return buttons;
	},

	getKeys: function (config) {
		var keys = [];

		var component = [
			'left', 'start', 'stop'
		];

		var add = {
			startAction: {
				key: Ext.EventObject.S,
				ctrl: true,
				fn: this.startAction,
				scope: this
			},
			stop: {
				key: Ext.EventObject.ENTER,
				fn: this.stopAction,
				scope: this
			}
		};

		component.filter(function (field) {
			if (add[field]) {
				keys.push(add[field]);
			}
		});

		return keys;
	},

	getListeners: function (config) {
		var listeners = {
			show: {
				fn: function () {
					var $this = this;

					var parentId = Ext.fly($this.id).child('input.sync-parent').id;
					var parentCombo = Ext.getCmp(parentId);
					if (parentCombo) {
						parentCombo.setValue($this.record['sync_resource']);
					}

				},
				scope: this
			}
		};

		return Ext.applyIf(config.listeners || {}, listeners);
	},

	close: function () {
		sync.window.sync.superclass.close.call(this);
	},

	stopAction: function () {
		this.setControlDisable(false);

		if (!this.stop) {
			this.stop = true;
		}
		else {
			this.stop = false;
			this.startAction(false, null, true)
		}

		this.setButtonStopText(this.stop)
	},

	startAction: function (close, event, stop) {
		this.stop = false;

		if (!stop) {
			this.setBaseParams(this.record);
			sync.tools.renderSyncResponse({}, this, true);
		}

		this.setControlDisable(true);
		this.setButtonStopText(this.stop);

		this.submit();
	},

	submit: function (close) {

		close = close === false ? false : true;
		var f = this.fp.getForm();
		f.timeout = 0;

		if (!this.stop && f.isValid() && this.fireEvent('beforeSubmit', f.getValues())) {
			f.submit({
				scope: this,
				failure: function (frm, a) {
					Ext.Ajax.timeout = 0;

					try {
						var r = Ext.decode(a.response.responseText);
					}
					catch (e) {
						console.log(e);
						return;
					}

					sync.tools.renderSyncResponse(r, this);

					this.setControlDisable(false);
				},

				success: function (frm, a) {
					Ext.Ajax.timeout = 0;

					try {
						var r = Ext.decode(a.response.responseText);
					}
					catch (e) {
						console.log(e);
						return;
					}

					sync.tools.renderSyncResponse(r, this);

					if (r.step) {
						this.setBaseParams({sync_step: r.step});
					}

					if (r.data && r.data['request']) {
						this.setBaseParams(r.data['request']);
					}

					if (!r.continue) {
						console.log('complete');
						this.fireEvent('complete');

						this.setControlDisable(false);
						return;
					}

					if (this.isVisible()) {
						var form = this;
						var refreshDelay = parseFloat(MODx.config['sync_refresh_delay'] || 0.1) * 1000;
						window.setTimeout(function () {
							form.submit();
						}, refreshDelay);
					}
				}
			});
		}

	},

	setBaseParams: function (record, clear) {
		var f = this.fp.getForm();

		if (f && clear && !record) {
			record = {action: this.action};
		}
		if (f && record) {
			for (var i in record) {
				if (!record.hasOwnProperty(i)) {
					continue;
				}
				f.baseParams[i] = record[i];
			}
		}
	},

	setControlDisable: function (disable) {
		this.setButtonStartDisable(disable);
		this.setComboParentDisable(disable);
	},

	setButtonStartDisable: function (disable) {
		var b = this.getButton('start');

		if (!b) {
			return;
		}
		if (disable) {
			b.onDisable();
		}
		else {
			b.onEnable();
		}
	},

	setComboParentDisable: function (disable) {
		var b = this.getButton('parent');

		if (!b) {
			return;
		}
		if (disable) {
			b.disable();
		}
		else {
			b.enable();
		}
	},

	setButtonStopText: function (stop) {
		var b = this.getButton('stop');

		if (!b) {
			return;
		}
		if (stop) {
			b.setText(_('sync_button_play'));
		}
		else {
			b.setText(_('sync_button_stop'));
		}
	},

	getButton: function (buttonNames) {
		var button = null;

		if (buttonNames && this.toolbars) {
			Ext.iterate(this.toolbars[0].items.items, function (btn, id) {
				if (btn['name'] == buttonNames) {
					button = btn;
					return true;
				}
			});
		}

		if (buttonNames && this.buttons) {
			Ext.iterate(this.buttons, function (btn, id) {
				if (btn['name'] == buttonNames) {
					button = btn;
					return true;
				}
			});
		}

		return button;
	},

	loadDropZones: function () {

	}

});
Ext.reg('sync-window-sync', sync.window.sync);
