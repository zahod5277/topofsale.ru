var sync = function (config) {
	config = config || {};
	sync.superclass.constructor.call(this, config);
};
Ext.extend(sync, Ext.Component, {
	page: {}, window: {}, grid: {}, tree: {}, panel: {}, combo: {}, config: {}, view: {}, tools: {}, actions: {}
});
Ext.reg('sync', sync);

sync = new sync();