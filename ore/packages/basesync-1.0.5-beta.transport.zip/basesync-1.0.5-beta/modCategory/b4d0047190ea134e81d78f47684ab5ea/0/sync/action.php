<?php

//ini_set('display_errors', 1);
//ini_set('error_reporting', -1);

ini_set('apc.cache_by_default', 'Off');

if (php_sapi_name() == "cli") {
    $params = array();
    array_shift($argv);
    foreach (@$argv as $k => $v) {
        parse_str($v, $params);
        $_REQUEST = array_merge($_REQUEST, $params);
    }
}
else {
    header('Content-Type:text/html;charset=utf-8');
    if (isset($_REQUEST['pre'])) {
        echo "<pre>";
    }
}


define('MODX_REQP', false);
define('MODX_API_MODE', true);
define('MODX_ACTION_MODE', true);

$productionConfig = dirname(dirname(dirname(dirname(__FILE__)))) . '/config.core.php';
$developmentConfig = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/config.core.php';
if (file_exists($productionConfig)) {
    /** @noinspection PhpIncludeInspection */
    require_once $productionConfig;
} else {
    /** @noinspection PhpIncludeInspection */
    require_once $developmentConfig;
}
/** @noinspection PhpIncludeInspection */
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
/** @noinspection PhpIncludeInspection */
require_once MODX_CONNECTORS_PATH . 'index.php';


$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');
$modx->error->message = null;

$ctx = !empty($_REQUEST['ctx']) ? $_REQUEST['ctx'] : 'web';
if ($ctx != 'web') {
    $modx->switchContext($ctx);
    $modx->user = null;
    $modx->getUser($ctx);
}

$_REQUEST = array_merge(array(
    'response_output_format'          => 'array',
    'response_send_continue_redirect' => true
), $_REQUEST);

/** @var Sync $Sync */
$Sync = $modx->getService('sync', 'Sync',
    $modx->getOption('sync_core_path', null,
        $modx->getOption('core_path') . 'components/sync/') . 'model/sync/');
//$modx->addPackage('sync', $Sync->config['modelPath']);
$modx->lexicon->load('sync:default');


$service = $modx->getOption('service', $_REQUEST, 'sync', true);
$corePath = $modx->getOption('sync_core_path', null, $modx->getOption('core_path') . 'components/sync/');
$corePath = $Sync->getServiceCorePath($service, $corePath);

$Sync->initialize($ctx);
if (!$response = $Sync->runProcessor($_REQUEST['action'], $_REQUEST, $corePath . 'processors/')) {
    $response = $modx->toJSON(array(
        'success' => false,
        'code'    => 401,
    ));
}

@session_write_close();
echo $response;
