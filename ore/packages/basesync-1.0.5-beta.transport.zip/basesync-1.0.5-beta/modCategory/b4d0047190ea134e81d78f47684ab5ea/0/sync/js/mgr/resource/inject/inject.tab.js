
/*add tab */
/*
Ext.ComponentMgr.onAvailable('modx-resource-tabs', function () {
	var syncOverrideTabs = this;

	syncOverrideTabs.on('beforerender', function () {
		syncOverrideTabs.add({
			title: _('sync'),
			hideMode: 'offsets',
			items: [{
				xtype: 'sync-panel-resource-sync',
				record: sync.config['resource']
			}]
		});
	});
});
*/

var syncOverridePanel = MODx.panel.Resource;
/* костыль под старую версию минишоп */
if (typeof(miniShop2) != 'undefined' && miniShop2.panel) {
	syncOverridePanel = miniShop2.panel.Product ? miniShop2.panel.Product : miniShop2.panel.UpdateCategory;
}
/* костыль под старую версию минишоп */


Ext.override(syncOverridePanel, {
	syncRecord: {},

	syncOriginals: {
		getFields: syncOverridePanel.prototype.getFields,
	/*	beforeSubmit: syncOverridePanel.prototype.beforeSubmit,
		success: syncOverridePanel.prototype.success*/
	},

	getFields: function(config) {
		var fields = this.syncOriginals.getFields.call(this, config);
		var show = parseInt(MODx.config['sync_show_sync_data']) || false;

		fields.filter(function(row) {
			if (show && row.id == 'modx-resource-tabs') {
				row.items.push({
					title: _('sync'),
					xtype: 'sync-panel-resource-sync',
					record: sync.config['resource']
				});
			}
		});

		return fields;
	},

});




var syncOverridePage = MODx.page.UpdateResource;

/* костыль под старую версию минишоп */
if (typeof(miniShop2) != 'undefined' && miniShop2.page) {
	syncOverridePage = miniShop2.page.UpdateCategory ? miniShop2.page.UpdateCategory : MODx.page.UpdateResource;
}
/* костыль под старую версию минишоп */

/*add button */
Ext.override(syncOverridePage, {

	syncOriginals: {
		getButtons: syncOverridePage.prototype.getButtons,
	},

	getSyncServiceActions: function (config) {
		var actions = sync.config['sync_service_actions'] || [];

		return actions;
	},

	getSyncSystemActions: function (config) {
		var actions = sync.config['sync_system_actions'] || [];

		return actions;
	},

	getButtons: function (config) {
		var add = [];
		var menu = [];
		var buttons = [];
		var originals = this.syncOriginals.getButtons.call(this, config);

		var actions = this.getSyncServiceActions(config);
		for (var service in actions) {
			if (!actions.hasOwnProperty(service)) {
				continue;
			}

			if (sync.tools.empty(actions[service])) {
				continue;
			}

			/* TODO service filter */

			for (var action in actions[service]) {
				if (!actions[service].hasOwnProperty(action)) {
					continue;
				}

				add.push({
					text: '&nbsp;' + (_('sync_action_' + action) || action),
					cls: 'sync-cogs',
					service: service,
					resource: config.record.id || 0,
					name: action,
					action: actions[service][action],
					handler: sync.actions.sync,
					scope: this
				});
			}

			menu.push({
				text: '&nbsp;' + (_('sync_' + service) || service),
				cls: 'sync-cogs',
				menu: add,
				handler: null
			});
			add = [];
		}

		/* add system */
		add = [];
		actions = this.getSyncSystemActions(config);
		for (action in actions) {
			if (!actions.hasOwnProperty(action)) {
				continue;
			}

			add.push({
				text: '&nbsp;' + (_('sync_action_' + action) || action),
				menu: null,
				cls: 'sync-cogs',
				service: 'sync',
				resource: config.record.id || 0,
				name: action,
				action: actions[action],
				handler: this._handlerSystemActions,
				scope: this
			});
		}

		/* add separator */
		if (!sync.tools.empty(menu)) {
			menu.push('-');
		}

		if (!sync.tools.empty(add)) {
			menu.push({
				text: '&nbsp;' + _('sync_service_system'),
				cls: 'sync-cogs',
				menu: add,
				handler: null
			});
		}

		buttons.push({
			xtype: 'button',
			text: _('sync'),
			menu: menu,
			handler: this._handlerStop,
		});

		for (var i in originals) {
			if (!originals.hasOwnProperty(i)) {
				continue;
			}
			var button = originals[i];
			buttons.push(button)
		}

		return buttons;
	},

	_handlerStop: function (btn, e) {
		e.stopEvent();
		e.preventDefault();
	},

	_handlerSystemActions: function (btn, e) {

		var service = btn.service || 'sync';
		var name = btn.name || 'sync';
		var action = btn.action || 'sync';
		var resource = btn.resource || 0;

		var params = {
			service: service,
			action: 'mgr/' + action,
			sync_resource: resource
		};

		Ext.MessageBox.confirm(
			_('action'),
			_('sync_confirm_' + name),
			function (val) {
				if (val == 'yes') {
					Ext.Ajax.timeout = 0;
					MODx.Ajax.request({
						url: sync.config['connector_url'],
						params: params,
						listeners: {
							success: {
								fn: function () {
								},
								scope: this
							},
							failure: {
								fn: function (response) {
									MODx.msg.alert(_('error'), response.message);
								},
								scope: this
							}
						}
					})
				}
			},
			this
		);
	},

});


