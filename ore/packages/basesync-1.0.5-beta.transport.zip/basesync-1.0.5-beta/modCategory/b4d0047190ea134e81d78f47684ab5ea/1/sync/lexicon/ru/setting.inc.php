<?php

$_lang['area_sync_main'] = 'Основные';

$_lang['setting_sync_refresh_delay'] = 'Пауза обновления';
$_lang['setting_sync_refresh_delay_desc'] = 'Пауза в секундах между запросами к серверу.';

$_lang['setting_sync_working_templates'] = 'Активные шаблоны';
$_lang['setting_sync_working_templates_desc'] = 'Список id шаблонов через запятую, для которых нужно активировать синхронизацию';

$_lang['setting_sync_not_working_templates'] = 'Неактивные шаблоны';
$_lang['setting_sync_not_working_templates_desc'] = 'Список id шаблонов через запятую, которых нужно исключить из синхронизации';

$_lang['setting_sync_show_sync_data'] = 'Показывать данные синхронизации';
$_lang['setting_sync_show_sync_data_desc'] = 'Показывать данные синхронизации в админке';

$_lang['setting_sync_actions'] = 'Доступные действия';
$_lang['setting_sync_actions_desc'] = 'Доступные действия';

$_lang['setting_sync_user_username'] = 'Логин пользователя синхронизации';
$_lang['setting_sync_user_username_desc'] = 'Логин пользователя синхронизации';

$_lang['setting_sync_user_password'] = 'Пароль пользователя синхронизации';
$_lang['setting_sync_user_password_desc'] = 'Пароль пользователя синхронизации';

$_lang['setting_sync_tools'] = 'Сервисы синхронизации';
$_lang['setting_sync_tools_desc'] = 'Сервисы синхронизации. Используется сторонними дополнениями для загрузки своего функционала.';

$_lang['setting_sync_show_sync_log'] = 'Показать лог';
$_lang['setting_sync_show_sync_log_desc'] = 'Показать лог работы';

