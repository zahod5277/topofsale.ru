<?php
require_once (dirname(dirname(__FILE__)) . '/syncobject.class.php');
class syncObject_mysql extends syncObject {}