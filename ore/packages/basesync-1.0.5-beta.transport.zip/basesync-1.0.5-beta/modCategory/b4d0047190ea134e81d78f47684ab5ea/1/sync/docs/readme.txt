--------------------
baseSync
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
