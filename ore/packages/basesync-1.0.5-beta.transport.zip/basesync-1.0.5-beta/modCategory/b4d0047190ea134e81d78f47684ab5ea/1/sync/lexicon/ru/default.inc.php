<?php

include_once 'errors.inc.php';
include_once 'manager.inc.php';
include_once 'setting.inc.php';

$_lang['sync'] = 'Синхронизация';

